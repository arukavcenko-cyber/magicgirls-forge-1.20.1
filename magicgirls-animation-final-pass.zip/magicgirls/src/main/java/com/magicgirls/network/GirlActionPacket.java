package com.magicgirls.network;

import com.magicgirls.entity.GirlEntity;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: the player pressed a button in the interaction menu. */
public class GirlActionPacket {
    private final int entityId;
    private final int action;

    public GirlActionPacket(int entityId, int action) {
        this.entityId = entityId;
        this.action = action;
    }

    public static void encode(GirlActionPacket msg, FriendlyByteBuf buf) {
        buf.writeVarInt(msg.entityId);
        buf.writeVarInt(msg.action);
    }

    public static GirlActionPacket decode(FriendlyByteBuf buf) {
        return new GirlActionPacket(buf.readVarInt(), buf.readVarInt());
    }

    public static void handle(GirlActionPacket msg, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer player = c.getSender();
            if (player == null) {
                return;
            }
            Entity e = player.level().getEntity(msg.entityId);
            if (e instanceof GirlEntity girl && player.distanceToSqr(girl) < 64.0D) {
                girl.handleAction(player, msg.action);
            }
        });
        c.setPacketHandled(true);
    }
}
