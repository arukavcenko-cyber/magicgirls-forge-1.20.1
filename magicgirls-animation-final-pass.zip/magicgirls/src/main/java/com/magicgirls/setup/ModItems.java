package com.magicgirls.setup;

import com.magicgirls.MagicGirlsMod;
import com.magicgirls.entity.GirlType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MagicGirlsMod.MOD_ID);

    public static final RegistryObject<Item> BEZE_EGG = egg("beze_spawn_egg", GirlType.BEZE, ModEntities.BEZE);
    public static final RegistryObject<Item> KIWI_EGG = egg("kiwi_spawn_egg", GirlType.KIWI, ModEntities.KIWI);
    public static final RegistryObject<Item> AZUR_EGG = egg("azur_spawn_egg", GirlType.AZUR, ModEntities.AZUR);
    public static final RegistryObject<Item> MAGENTA_EGG = egg("magenta_spawn_egg", GirlType.MAGENTA, ModEntities.MAGENTA);
    public static final RegistryObject<Item> VIKA_EGG = egg("vika_spawn_egg", GirlType.VIKA, ModEntities.VIKA);
    public static final RegistryObject<Item> SULFUR_EGG = egg("sulfur_spawn_egg", GirlType.SULFUR, ModEntities.SULFUR);

    public static final RegistryObject<Item> VIKA_PORTAL = ITEMS.register("vika_portal",
            () -> new BlockItem(ModBlocks.VIKA_PORTAL.get(), new Item.Properties()));

    private ModItems() {}

    private static RegistryObject<Item> egg(String id, GirlType type,
                                            RegistryObject<? extends net.minecraft.world.entity.EntityType<? extends net.minecraft.world.entity.Mob>> entity) {
        return ITEMS.register(id, () -> new ForgeSpawnEggItem(entity::get, type.eggPrimary, type.eggSecondary,
                new Item.Properties()));
    }
}
