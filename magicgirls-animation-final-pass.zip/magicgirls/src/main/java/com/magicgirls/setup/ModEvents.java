package com.magicgirls.setup;

import com.magicgirls.MagicGirlsMod;
import com.magicgirls.command.GirlCommands;
import com.magicgirls.entity.GirlEntity;
import com.magicgirls.entity.GirlType;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerSleepInBedEvent;
import net.minecraftforge.event.entity.player.PlayerWakeUpEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

public final class ModEvents {
    private ModEvents() {}

    /** Events on the mod loading bus. */
    @Mod.EventBusSubscriber(modid = MagicGirlsMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class ModBus {
        @SubscribeEvent
        public static void attributes(EntityAttributeCreationEvent e) {
            for (GirlType t : GirlType.values()) {
                AttributeSupplier.Builder b = GirlEntity.attributes(t);
                e.put(ModEntities.of(t), b.build());
            }
        }

        @SubscribeEvent
        public static void spawnPlacements(SpawnPlacementRegisterEvent e) {
            e.register(ModEntities.AZUR.get(), SpawnPlacements.Type.ON_GROUND,
                    Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, ModEvents::checkAzurSpawn,
                    SpawnPlacementRegisterEvent.Operation.REPLACE);
        }

        @SubscribeEvent
        public static void tabs(BuildCreativeModeTabContentsEvent e) {
            if (e.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
                e.accept(ModItems.BEZE_EGG);
                e.accept(ModItems.KIWI_EGG);
                e.accept(ModItems.AZUR_EGG);
                e.accept(ModItems.MAGENTA_EGG);
                e.accept(ModItems.VIKA_EGG);
                e.accept(ModItems.SULFUR_EGG);
            } else if (e.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
                e.accept(ModItems.VIKA_PORTAL);
            }
        }
    }

    /** Natural Azur spawn is also capped: at most one within 96 blocks. */
    static boolean checkAzurSpawn(EntityType<GirlEntity> type, net.minecraft.world.level.ServerLevelAccessor level,
                                  MobSpawnType reason, BlockPos pos, net.minecraft.util.RandomSource random) {
        if (!net.minecraft.world.entity.Mob.checkMobSpawnRules(type, level, reason, pos, random)) {
            return false;
        }
        return level.getEntitiesOfClass(GirlEntity.class, new AABB(pos).inflate(96.0D),
                g -> g.getGirlType() == GirlType.AZUR).isEmpty();
    }

    /** Events on the Forge bus. */
    @Mod.EventBusSubscriber(modid = MagicGirlsMod.MOD_ID)
    public static final class ForgeBus {
        private static final String KIWI_FLAG = "magicgirls_kiwi_spawned";

        @SubscribeEvent
        public static void commands(RegisterCommandsEvent e) {
            GirlCommands.register(e.getDispatcher());
        }

        /** Kiwi appears the first time a player enters a world. */
        @SubscribeEvent
        public static void login(PlayerEvent.PlayerLoggedInEvent e) {
            if (!GirlConfig.KIWI_ON_FIRST_JOIN.get() || !(e.getEntity() instanceof ServerPlayer player)) {
                return;
            }
            CompoundTag data = player.getPersistentData();
            CompoundTag persisted = data.getCompound(Player.PERSISTED_NBT_TAG);
            if (persisted.getBoolean(KIWI_FLAG)) {
                return;
            }
            persisted.putBoolean(KIWI_FLAG, true);
            data.put(Player.PERSISTED_NBT_TAG, persisted);

            ServerLevel level = player.serverLevel();
            BlockPos target = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING,
                    player.blockPosition().offset(2, 0, 2));
            GirlEntity kiwi = ModEntities.KIWI.get().create(level);
            if (kiwi != null) {
                kiwi.moveTo(target.getX() + 0.5D, target.getY(), target.getZ() + 0.5D, player.getYRot() + 180.0F, 0.0F);
                level.addFreshEntity(kiwi);
                kiwi.say(player, "Наконец-то ты появился. Я Киви. Подойди и нажми на меня правой кнопкой — поговорим.");
            }
        }

        /** Magenta appears near villages: every 30 s, if 3+ villagers are around and no Magenta is nearby. */
        @SubscribeEvent
        public static void playerTick(TickEvent.PlayerTickEvent e) {
            if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer player)
                    || !GirlConfig.MAGENTA_IN_VILLAGES.get() || player.tickCount % 600 != 0) {
                return;
            }
            ServerLevel level = player.serverLevel();
            List<Villager> villagers = level.getEntitiesOfClass(Villager.class, player.getBoundingBox().inflate(48.0D));
            if (villagers.size() < 3 || level.random.nextInt(100) >= GirlConfig.MAGENTA_CHANCE_PERCENT.get()) {
                return;
            }
            AABB wide = player.getBoundingBox().inflate(96.0D);
            if (!level.getEntitiesOfClass(GirlEntity.class, wide, g -> g.getGirlType() == GirlType.MAGENTA).isEmpty()) {
                return;
            }
            Villager v = villagers.get(level.random.nextInt(villagers.size()));
            GirlEntity magenta = ModEntities.MAGENTA.get().create(level);
            if (magenta != null) {
                magenta.moveTo(v.getX() + 1.5D, v.getY(), v.getZ() + 1.5D, level.random.nextFloat() * 360.0F, 0.0F);
                level.addFreshEntity(magenta);
            }
        }

        /** Special lines when a player lies down in a bed near a girl. */
        @SubscribeEvent
        public static void sleep(PlayerSleepInBedEvent e) {
            Player p = e.getEntity();
            if (p.level().isClientSide) {
                return;
            }
            for (GirlEntity g : p.level().getEntitiesOfClass(GirlEntity.class, p.getBoundingBox().inflate(10.0D))) {
                g.reactToPlayerBed(p);
            }
        }

        @SubscribeEvent
        public static void wake(PlayerWakeUpEvent e) {
            Player p = e.getEntity();
            if (p.level().isClientSide) {
                return;
            }
            for (GirlEntity g : p.level().getEntitiesOfClass(GirlEntity.class, p.getBoundingBox().inflate(16.0D))) {
                if (g.isSleeping() && g.isFollowing()) {
                    g.wakeUp();
                }
            }
        }
    }
}
