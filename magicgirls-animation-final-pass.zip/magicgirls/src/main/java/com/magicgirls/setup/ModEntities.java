package com.magicgirls.setup;

import com.magicgirls.MagicGirlsMod;
import com.magicgirls.entity.GirlEntity;
import com.magicgirls.entity.GirlType;
import com.magicgirls.entity.VikaBolt;
import com.magicgirls.entity.VikaEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MagicGirlsMod.MOD_ID);

    public static final RegistryObject<EntityType<GirlEntity>> BEZE =
            girl("beze", (t, l) -> new GirlEntity(t, l, GirlType.BEZE));
    public static final RegistryObject<EntityType<GirlEntity>> KIWI =
            girl("kiwi", (t, l) -> new GirlEntity(t, l, GirlType.KIWI));
    public static final RegistryObject<EntityType<GirlEntity>> AZUR =
            girl("azur", (t, l) -> new GirlEntity(t, l, GirlType.AZUR));
    public static final RegistryObject<EntityType<GirlEntity>> MAGENTA =
            girl("magenta", (t, l) -> new GirlEntity(t, l, GirlType.MAGENTA));
    public static final RegistryObject<EntityType<VikaEntity>> VIKA = girl("vika", VikaEntity::new);
    public static final RegistryObject<EntityType<GirlEntity>> SULFUR =
            girl("sulfur", (t, l) -> new GirlEntity(t, l, GirlType.SULFUR));

    public static final RegistryObject<EntityType<VikaBolt>> VIKA_BOLT = ENTITIES.register("vika_bolt",
            () -> EntityType.Builder.<VikaBolt>of(VikaBolt::new, MobCategory.MISC)
                    .sized(0.3F, 0.3F).clientTrackingRange(4).updateInterval(5).build("vika_bolt"));

    private ModEntities() {}

    private static <T extends GirlEntity> RegistryObject<EntityType<T>> girl(String id, EntityType.EntityFactory<T> factory) {
        return ENTITIES.register(id, () -> EntityType.Builder.of(factory, MobCategory.CREATURE)
                .sized(0.6F, 1.8F).clientTrackingRange(10).build(id));
    }

    public static EntityType<? extends GirlEntity> of(GirlType type) {
        switch (type) {
            case BEZE: return BEZE.get();
            case KIWI: return KIWI.get();
            case AZUR: return AZUR.get();
            case MAGENTA: return MAGENTA.get();
            case VIKA: return VIKA.get();
            case SULFUR: return SULFUR.get();
            default: throw new IllegalArgumentException("Unknown girl type: " + type);
        }
    }
}
