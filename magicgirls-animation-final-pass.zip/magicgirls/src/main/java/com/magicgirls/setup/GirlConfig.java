package com.magicgirls.setup;

import net.minecraftforge.common.ForgeConfigSpec;

public final class GirlConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue KIWI_ON_FIRST_JOIN;
    public static final ForgeConfigSpec.BooleanValue MAGENTA_IN_VILLAGES;
    public static final ForgeConfigSpec.IntValue MAGENTA_CHANCE_PERCENT;
    public static final ForgeConfigSpec.DoubleValue VIKA_BOLT_DAMAGE;
    public static final ForgeConfigSpec.IntValue FOLLOW_TELEPORT_DISTANCE;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("spawning");
        KIWI_ON_FIRST_JOIN = b.comment("Spawn Kiwi next to a player the first time they join a world.")
                .define("kiwiOnFirstJoin", true);
        MAGENTA_IN_VILLAGES = b.comment("Allow Magenta to appear near villagers.")
                .define("magentaInVillages", true);
        MAGENTA_CHANCE_PERCENT = b.comment("Chance per check (every 30 s near 3+ villagers, no Magenta within 96 blocks).")
                .defineInRange("magentaChancePercent", 35, 0, 100);
        b.pop();
        b.push("combat");
        VIKA_BOLT_DAMAGE = b.defineInRange("vikaBoltDamage", 5.0D, 1.0D, 40.0D);
        b.pop();
        b.push("ai");
        FOLLOW_TELEPORT_DISTANCE = b.comment("A following girl teleports to the owner beyond this distance.")
                .defineInRange("followTeleportDistance", 20, 8, 64);
        b.pop();
        SPEC = b.build();
    }

    private GirlConfig() {}
}
