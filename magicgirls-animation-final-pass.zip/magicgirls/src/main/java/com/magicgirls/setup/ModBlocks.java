package com.magicgirls.setup;

import com.magicgirls.MagicGirlsMod;
import com.magicgirls.block.VikaPortalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, MagicGirlsMod.MOD_ID);

    public static final RegistryObject<Block> VIKA_PORTAL = BLOCKS.register("vika_portal",
            () -> new VikaPortalBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_MAGENTA).strength(3.0F, 6.0F)
                    .sound(SoundType.AMETHYST).lightLevel(s -> 10)));

    private ModBlocks() {}
}
