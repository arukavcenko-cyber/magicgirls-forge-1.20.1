package com.magicgirls.client;

import com.magicgirls.MagicGirlsMod;
import com.magicgirls.entity.GirlEntity;
import com.magicgirls.entity.GirlType;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Client-side visual feedback for Sulfur petting. While the player holds the
 * use/right-click key near Sulfur in PET state, replay the vanilla arm swing.
 * This intentionally changes only the local player's animation; the server
 * remains authoritative for the companion state and affection particles.
 */
@Mod.EventBusSubscriber(modid = MagicGirlsMod.MOD_ID, value = Dist.CLIENT)
public final class ClientPettingAnimation {
    private static int swingCooldown;

    private ClientPettingAnimation() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.screen != null) {
            swingCooldown = 0;
            return;
        }

        boolean pettingSulfur = mc.level.getEntitiesOfClass(GirlEntity.class,
                mc.player.getBoundingBox().inflate(3.25D),
                girl -> girl.getGirlType() == GirlType.SULFUR
                        && girl.getState() == GirlEntity.STATE_PET).stream().findAny().isPresent();

        if (!pettingSulfur || !mc.options.keyUse.isDown()) {
            swingCooldown = 0;
            return;
        }

        if (swingCooldown > 0) {
            swingCooldown--;
        } else {
            mc.player.swing(InteractionHand.MAIN_HAND);
            swingCooldown = 7;
        }
    }
}
