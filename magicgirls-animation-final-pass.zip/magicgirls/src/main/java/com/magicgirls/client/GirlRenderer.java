package com.magicgirls.client;

import com.magicgirls.MagicGirlsMod;
import com.magicgirls.client.model.GirlModel;
import com.magicgirls.entity.GirlEntity;
import com.magicgirls.entity.GirlType;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class GirlRenderer extends MobRenderer<GirlEntity, GirlModel> {
    private final ResourceLocation normal;
    private final ResourceLocation happy;
    private final ResourceLocation sleep;

    public GirlRenderer(EntityRendererProvider.Context ctx, GirlType type) {
        super(ctx, new GirlModel(ctx.bakeLayer(GirlModel.layer(type)), type), 0.45F);
        String base = "textures/entity/" + type.id;
        this.normal = new ResourceLocation(MagicGirlsMod.MOD_ID, base + ".png");
        this.happy = new ResourceLocation(MagicGirlsMod.MOD_ID, base + "_happy.png");
        this.sleep = new ResourceLocation(MagicGirlsMod.MOD_ID, base + "_sleep.png");
    }

    @Override
    public ResourceLocation getTextureLocation(GirlEntity entity) {
        if (entity.isSleeping()) {
            return sleep;
        }
        return entity.getState() == GirlEntity.STATE_HUG ? happy : normal;
    }

    @Override
    protected void scale(GirlEntity entity, PoseStack pose, float partialTick) {
        pose.scale(0.85F, 0.85F, 0.85F);
    }
}
