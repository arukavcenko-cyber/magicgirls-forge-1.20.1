package com.magicgirls.client;

import com.magicgirls.MagicGirlsMod;
import com.magicgirls.client.model.GirlModel;
import com.magicgirls.client.model.GirlModels;
import com.magicgirls.entity.GirlEntity;
import com.magicgirls.entity.GirlType;
import com.magicgirls.setup.ModEntities;
import net.minecraft.client.renderer.entity.NoopRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = MagicGirlsMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    private ClientModEvents() {}

    @SubscribeEvent
    public static void layers(EntityRenderersEvent.RegisterLayerDefinitions e) {
        for (GirlType t : GirlType.values()) {
            e.registerLayerDefinition(GirlModel.layer(t), () -> GirlModels.create(t));
        }
    }

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        for (GirlType t : GirlType.values()) {
            e.<GirlEntity>registerEntityRenderer(ModEntities.of(t), ctx -> new GirlRenderer(ctx, t));
        }
        e.registerEntityRenderer(ModEntities.VIKA_BOLT.get(), NoopRenderer::new);
    }
}
