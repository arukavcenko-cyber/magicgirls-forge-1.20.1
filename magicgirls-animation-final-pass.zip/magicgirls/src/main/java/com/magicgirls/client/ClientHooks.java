package com.magicgirls.client;

import com.magicgirls.entity.GirlEntity;
import net.minecraft.client.Minecraft;

/** Client-only helpers, kept out of common classes so a dedicated server never loads them. */
public final class ClientHooks {
    private ClientHooks() {}

    public static void openMenu(GirlEntity girl) {
        Minecraft.getInstance().setScreen(new GirlMenuScreen(girl));
    }
}
