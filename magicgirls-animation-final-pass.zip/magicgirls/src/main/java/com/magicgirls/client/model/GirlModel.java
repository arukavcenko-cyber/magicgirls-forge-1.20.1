package com.magicgirls.client.model;

import com.magicgirls.MagicGirlsMod;
import com.magicgirls.entity.GirlEntity;
import com.magicgirls.entity.GirlType;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

import java.util.ArrayList;
import java.util.List;

/**
 * One model class for all six girls. Geometry comes from the generated GirlModels; animation is
 * procedural: idle, walk, run, jump, hurt, attack, hug, sleep, wake, plus hair/tail/wing sway.
 */
public class GirlModel extends EntityModel<GirlEntity> {
    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart body;
    private final ModelPart rArm;
    private final ModelPart lArm;
    private final ModelPart rLeg;
    private final ModelPart lLeg;
    private final ModelPart[] hair;
    private final ModelPart[] tail;
    private final ModelPart wingR;
    private final ModelPart wingL;

    public GirlModel(ModelPart root, GirlType type) {
        this.root = root;
        this.head = root.getChild("head");
        this.body = root.getChild("body");
        this.rArm = root.getChild("right_arm");
        this.lArm = root.getChild("left_arm");
        this.rLeg = root.getChild("right_leg");
        this.lLeg = root.getChild("left_leg");
        List<ModelPart> hairParts = new ArrayList<>();
        List<ModelPart> tailParts = new ArrayList<>();
        ModelPart wr = null;
        ModelPart wl = null;
        for (String path : GirlModels.PATHS[type.ordinal()]) {
            ModelPart p = root;
            String last = path;
            for (String seg : path.split("/")) {
                p = p.getChild(seg);
                last = seg;
            }
            if (last.startsWith("hair_tail") || last.startsWith("hair_curl") || last.startsWith("hair_back_")
                    || last.startsWith("hair_front_lock") || last.startsWith("hair_back_lock")) {
                hairParts.add(p);
            } else if (last.startsWith("tail_")) {
                tailParts.add(p);
            } else if (last.equals("wing_r")) {
                wr = p;
            } else if (last.equals("wing_l")) {
                wl = p;
            }
        }
        this.hair = hairParts.toArray(new ModelPart[0]);
        this.tail = tailParts.toArray(new ModelPart[0]);
        this.wingR = wr;
        this.wingL = wl;
    }

    public static ModelLayerLocation layer(GirlType type) {
        return new ModelLayerLocation(new ResourceLocation(MagicGirlsMod.MOD_ID, type.id), "main");
    }

    @Override
    public void setupAnim(GirlEntity e, float limbSwing, float limbSwingAmount, float age, float yaw, float pitch) {
        this.root.getAllParts().forEach(ModelPart::resetPose);

        final boolean sleeping = e.isSleeping();
        final int state = e.getState();
        final boolean running = e.isSprinting();
        final boolean airborne = !e.onGround() && !e.isInWater();
        final float swing = Math.min(limbSwingAmount, 1.0F);

        if (!sleeping && state != GirlEntity.STATE_HUG && state != GirlEntity.STATE_PET) {
            head.yRot += Mth.clamp(yaw, -50.0F, 50.0F) * Mth.DEG_TO_RAD;
            head.xRot += pitch * Mth.DEG_TO_RAD;
        }

        // ---- idle: breathing and relaxed arms
        float breathe = Mth.sin(age * 0.07F);
        body.xRot += breathe * 0.012F;
        rArm.zRot += Mth.cos(age * 0.09F) * 0.05F + 0.05F;
        lArm.zRot -= Mth.cos(age * 0.09F) * 0.05F + 0.05F;
        rArm.xRot += Mth.sin(age * 0.067F) * 0.05F;
        lArm.xRot -= Mth.sin(age * 0.067F) * 0.05F;

        // ---- character-specific idle personalities (all six have distinct silhouettes in motion)
        if (!sleeping && swing < 0.12F && state == GirlEntity.STATE_NONE) {
            switch (e.getGirlType()) {
                case BEZE: // sleepy, slightly floating demon girl
                    body.yRot += Mth.sin(age * 0.035F) * 0.025F;
                    head.zRot += Mth.sin(age * 0.045F) * 0.035F;
                    rArm.xRot -= 0.06F + Mth.sin(age * 0.08F) * 0.035F;
                    lArm.xRot -= 0.06F + Mth.sin(age * 0.08F + 1.2F) * 0.035F;
                    break;
                case KIWI: // alert, disciplined stance
                    body.xRot -= 0.025F;
                    head.yRot += Mth.sin(age * 0.045F) * 0.045F;
                    rArm.zRot += 0.025F;
                    lArm.zRot -= 0.025F;
                    break;
                case AZUR: // composed, slow breathing
                    body.xRot += Mth.sin(age * 0.035F) * 0.018F;
                    head.xRot += Mth.sin(age * 0.025F) * 0.018F;
                    rArm.xRot += Mth.sin(age * 0.04F) * 0.025F;
                    lArm.xRot += Mth.sin(age * 0.04F + 0.5F) * 0.025F;
                    break;
                case MAGENTA: { // cheerful little bounce
                    float bounce = Math.max(0.0F, Mth.sin(age * 0.16F)) * 0.035F;
                    body.y += bounce;
                    head.xRot -= bounce * 0.7F;
                    rArm.zRot += Mth.sin(age * 0.16F) * 0.07F;
                    lArm.zRot -= Mth.sin(age * 0.16F) * 0.07F;
                    break;
                }
                case VIKA: // confident, slightly mischievous pose
                    body.yRot += Mth.sin(age * 0.055F) * 0.035F;
                    head.zRot += 0.035F + Mth.sin(age * 0.04F) * 0.018F;
                    rArm.zRot += 0.07F;
                    lArm.zRot -= 0.025F;
                    break;
                case SULFUR: // energetic fighter subtly flexes her gauntlets
                    rArm.xRot -= 0.07F + Mth.sin(age * 0.12F) * 0.035F;
                    lArm.xRot -= 0.07F + Mth.sin(age * 0.12F + 0.35F) * 0.035F;
                    body.xRot += Mth.sin(age * 0.12F) * 0.018F;
                    break;
            }
        }

        // ---- walk / run
        if (!sleeping && !airborne) {
            float w = limbSwing * (running ? 0.95F : 0.6662F);
            float legAmp = (running ? 1.5F : 1.2F) * swing;
            rLeg.xRot += Mth.cos(w) * legAmp;
            lLeg.xRot += Mth.cos(w + Mth.PI) * legAmp;
            rArm.xRot += Mth.cos(w + Mth.PI) * (running ? 1.3F : 0.9F) * swing;
            lArm.xRot += Mth.cos(w) * (running ? 1.3F : 0.9F) * swing;
            if (running && swing > 0.3F) {
                body.xRot += 0.18F;
                head.xRot -= 0.12F;
                rArm.xRot -= 0.35F;
                lArm.xRot -= 0.35F;
            }
        }

        // ---- jump / fall
        if (airborne && !sleeping) {
            rLeg.xRot += -0.45F;
            lLeg.xRot += 0.35F;
            rArm.zRot += 0.8F;
            lArm.zRot -= 0.8F;
        }

        // ---- attack
        if (this.attackTime > 0.0F) {
            float s = Mth.sin(this.attackTime * Mth.PI);
            float twist = Mth.sin(Mth.sqrt(this.attackTime) * Mth.TWO_PI) * 0.25F;
            body.yRot += twist;
            rArm.yRot += twist;
            lArm.yRot += twist;
            rArm.xRot += -1.9F * s;
            rArm.zRot += 0.2F * s;
            head.xRot += 0.15F * s;
            // Give each girl a recognizable attack accent instead of one identical swing.
            switch (e.getGirlType()) {
                case BEZE:
                    lArm.xRot -= 0.65F * s;
                    body.yRot -= 0.16F * s;
                    head.zRot += 0.08F * s;
                    break;
                case KIWI:
                    body.xRot += 0.12F * s;
                    lArm.xRot -= 0.35F * s;
                    break;
                case AZUR:
                    lArm.xRot -= 0.8F * s;
                    body.yRot += 0.12F * s;
                    break;
                case MAGENTA:
                    lArm.xRot -= 1.15F * s;
                    body.y += 0.045F * s;
                    break;
                case VIKA:
                    lArm.xRot -= 0.45F * s;
                    body.yRot -= 0.22F * s;
                    break;
                case SULFUR:
                    lArm.xRot -= 1.65F * s;
                    rArm.xRot -= 0.25F * s;
                    body.xRot += 0.18F * s;
                    break;
            }
        }

        // ---- hurt
        if (e.hurtTime > 0) {
            float k = e.hurtTime / 10.0F;
            head.xRot += -0.35F * k;
            body.xRot += -0.15F * k;
            rArm.zRot += 0.5F * k;
            lArm.zRot -= 0.5F * k;
        }

        // ---- hug / wake / sleep
        if (state == GirlEntity.STATE_PET) {
            // Sulfur leans toward the player and gives a small, happy hand/shoulder reaction.
            rArm.xRot = -0.95F + Mth.sin(age * 0.32F) * 0.12F;
            lArm.xRot = -0.95F + Mth.sin(age * 0.32F + 0.7F) * 0.12F;
            rArm.zRot = 0.18F;
            lArm.zRot = -0.18F;
            head.xRot += 0.18F + Mth.sin(age * 0.18F) * 0.035F;
            body.xRot += 0.035F;
        } else if (state == GirlEntity.STATE_HUG) {
            rArm.xRot = -1.25F;
            rArm.yRot = -0.6F;
            rArm.zRot = 0.0F;
            lArm.xRot = -1.25F;
            lArm.yRot = 0.6F;
            lArm.zRot = 0.0F;
            head.xRot += 0.12F + Mth.sin(age * 0.2F) * 0.03F;
            body.xRot += 0.05F;
        } else if (state == GirlEntity.STATE_GREETING) {
            // Short character greeting: a gentle wave with a small head tilt.
            float wave = Mth.sin(age * 0.42F);
            rArm.xRot = -2.35F + wave * 0.16F;
            rArm.zRot = -0.22F + wave * 0.10F;
            head.zRot += Mth.sin(age * 0.18F) * 0.045F;
            body.yRot += Mth.sin(age * 0.16F) * 0.025F;
            if (e.getGirlType() == GirlType.MAGENTA) {
                lArm.xRot = -1.35F + wave * 0.12F;
                body.y += Math.max(0.0F, Mth.sin(age * 0.32F)) * 0.035F;
            }
        } else if (state == GirlEntity.STATE_BYE) {
            // Farewell wave; the left arm joins for the more expressive Magenta and Beze.
            float wave = Mth.sin(age * 0.38F);
            rArm.xRot = -2.25F + wave * 0.20F;
            rArm.zRot = -0.18F + wave * 0.12F;
            head.zRot += 0.06F + Mth.sin(age * 0.14F) * 0.035F;
            if (e.getGirlType() == GirlType.MAGENTA || e.getGirlType() == GirlType.BEZE) {
                lArm.xRot = -1.9F + wave * 0.14F;
            }
            body.yRot += Mth.sin(age * 0.12F) * 0.035F;
        } else if (state == GirlEntity.STATE_GAUNTLET) {
            // Sulfur's paired mechanical fists swing forward together during her heavy strike.
            float punch = 0.5F + 0.5F * Mth.sin(age * 0.9F);
            rArm.xRot = -2.15F - 0.35F * punch;
            lArm.xRot = -2.15F - 0.35F * punch;
            rArm.yRot = -0.18F;
            lArm.yRot = 0.18F;
            rArm.zRot = 0.12F;
            lArm.zRot = -0.12F;
            body.xRot += 0.12F;
            head.xRot -= 0.08F;
        } else if (state == GirlEntity.STATE_WAKE) {
            rArm.xRot = -2.8F + Mth.sin(age * 0.4F) * 0.06F;
            lArm.xRot = -2.8F + Mth.sin(age * 0.4F) * 0.06F;
            rArm.zRot = 0.25F;
            lArm.zRot = -0.25F;
            head.xRot += -0.3F;
            body.xRot += -0.08F;
        } else if (sleeping) {
            rArm.xRot = -0.35F;
            lArm.xRot = -0.35F;
            rArm.zRot = 0.1F;
            lArm.zRot = -0.1F;
            // Quiet breathing and a tiny sleeping head tilt; no walking sway while asleep.
            body.xRot += Mth.sin(age * 0.05F) * 0.02F;
            head.xRot = 0.18F + Mth.sin(age * 0.045F) * 0.012F;
            head.zRot += Mth.sin(age * 0.035F) * 0.018F;
        }

        // ---- outfit secondary motion: skirt panels, coat tails and ribbons
        String[][] outfitParts = {
                {"body/skirt", "body/skirt_back", "body/cape"},
                {"body/coat_skirt", "body/coat_tail"},
                {"body/skirt", "body/skirt_frill"},
                {"body/skirt", "body/skirt_back_bow_r", "body/skirt_back_bow_l"},
                {"body/skirt", "body/skirt_frill"},
                {"body/dress_skirt", "body/dress_hem"}
        };
        for (String path : outfitParts[e.getGirlType().ordinal()]) {
            ModelPart part = root;
            try {
                for (String segment : path.split("/")) part = part.getChild(segment);
                part.yRot += Mth.sin(age * 0.09F + limbSwing * 0.12F) * (0.025F + swing * 0.07F);
                part.xRot += swing * Mth.sin(limbSwing * 0.5F) * 0.035F;
            } catch (RuntimeException ignored) {
                // Some optional outfit pieces are intentionally absent from a model.
            }
        }

        // ---- secondary motion
        float sway = sleeping ? 0.0F : 1.0F;
        for (int i = 0; i < hair.length; i++) {
            ModelPart h = hair[i];
            h.xRot += (Mth.sin(age * 0.06F + i * 0.7F) * 0.035F + swing * 0.12F) * sway;
            h.zRot += Mth.sin(age * 0.05F + i * 1.3F) * 0.025F * sway;
        }
        for (int i = 0; i < tail.length; i++) {
            tail[i].yRot += Mth.sin(age * 0.1F - i * 0.6F) * 0.22F + swing * Mth.sin(limbSwing * 0.6F - i) * 0.3F;
            tail[i].xRot += airborne ? -0.2F : 0.0F;
        }
        if (wingR != null && wingL != null) {
            float flap = airborne ? Mth.sin(age * 0.9F) * 0.45F : Mth.sin(age * 0.12F) * 0.07F;
            wingR.yRot += flap;
            wingL.yRot -= flap;
        }
    }

    @Override
    public void renderToBuffer(PoseStack pose, VertexConsumer buffer, int light, int overlay,
                               float r, float g, float b, float a) {
        this.root.render(pose, buffer, light, overlay, r, g, b, a);
    }
}
