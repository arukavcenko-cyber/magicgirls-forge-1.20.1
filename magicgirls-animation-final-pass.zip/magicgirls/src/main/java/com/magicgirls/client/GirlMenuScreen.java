package com.magicgirls.client;

import com.magicgirls.entity.GirlEntity;
import com.magicgirls.network.GirlActionPacket;
import com.magicgirls.network.ModNetwork;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

/** Radial interaction wheel for the companion. */
public class GirlMenuScreen extends Screen {
    private static final String[] LABELS = {
            "Поговорить", "Обнять", "Следовать", "Стоп", "Ждать", "Спать", "Погладить", "Попрощаться"
    };
    private final GirlEntity girl;
    private int selected = -1;

    public GirlMenuScreen(GirlEntity girl) {
        super(Component.literal(girl.getGirlType().displayName));
        this.girl = girl;
    }

    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g);
        int cx = width / 2, cy = height / 2;
        int radius = Math.min(92, Math.min(width, height) / 3);
        double dx = mouseX - cx, dy = mouseY - cy;
        selected = -1;
        if (Math.hypot(dx, dy) > 25 && Math.hypot(dx, dy) < radius + 28) {
            double angle = Math.atan2(dy, dx) + Math.PI / 2.0;
            if (angle < 0) angle += Math.PI * 2.0;
            selected = (int)Math.floor((angle + Math.PI / 8.0) / (Math.PI / 4.0)) % 8;
        }
        g.drawCenteredString(font, title, cx, cy - radius - 24, girl.getGirlType().color);
        g.fill(cx - 22, cy - 22, cx + 22, cy + 22, 0xCC20202A);
        g.drawCenteredString(font, "✦", cx, cy - 4, 0xFFFFD56A);
        for (int i = 0; i < 8; i++) {
            double a = -Math.PI / 2.0 + i * Math.PI / 4.0;
            int x = cx + (int)(Math.cos(a) * radius);
            int y = cy + (int)(Math.sin(a) * radius);
            int color = i == selected ? 0xFFB978E8 : 0xDD303744;
            g.fill(x - 43, y - 13, x + 43, y + 13, color);
            g.drawCenteredString(font, LABELS[i], x, y - 4, 0xFFFFFFFF);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && selected >= 0) {
            int action = selected;
            // Petting is exclusive to Sulfur; other girls ignore this sector.
            if (action != 6 || girl.getGirlType().id.equals("sulfur")) {
                ModNetwork.CHANNEL.sendToServer(new GirlActionPacket(girl.getId(), action));
            }
            onClose();
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override public boolean isPauseScreen() { return false; }
}
