package com.magicgirls.entity;

import com.magicgirls.setup.GirlConfig;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/** Magic projectile fired by Vika. Flies straight, ignores gravity, never hurts any of the five girls. */
public class VikaBolt extends ThrowableProjectile {
    public VikaBolt(EntityType<? extends VikaBolt> type, Level level) {
        super(type, level);
    }

    public VikaBolt(EntityType<? extends VikaBolt> type, LivingEntity owner, Level level) {
        super(type, owner, level);
    }

    @Override
    protected void defineSynchedData() {
    }

    @Override
    protected float getGravity() {
        return 0.0F;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            this.level().addParticle(ParticleTypes.WITCH, getX(), getY(), getZ(), 0.0D, 0.0D, 0.0D);
            if (this.tickCount % 2 == 0) {
                this.level().addParticle(ParticleTypes.ELECTRIC_SPARK, getX(), getY(), getZ(), 0.0D, 0.0D, 0.0D);
            }
        } else if (this.tickCount > 80) {
            this.discard();
        }
    }

    @Override
    protected boolean canHitEntity(Entity target) {
        if (target instanceof GirlEntity) {
            return false;
        }
        if (getOwner() instanceof GirlEntity girl && girl.getOwnerPlayer() == target) {
            return false;
        }
        return super.canHitEntity(target);
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (!this.level().isClientSide) {
            result.getEntity().hurt(this.damageSources().indirectMagic(this, getOwner()),
                    GirlConfig.VIKA_BOLT_DAMAGE.get().floatValue());
        }
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!this.level().isClientSide) {
            this.discard();
        }
    }
}
