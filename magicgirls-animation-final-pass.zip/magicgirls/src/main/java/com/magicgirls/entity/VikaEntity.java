package com.magicgirls.entity;

import com.magicgirls.setup.ModEntities;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * Vika. Starts as a 50 HP boss when summoned through the Nether portal; once beaten she becomes
 * the player's companion. Abilities: magic bolt, dash, protective shield, multi-bolt barrage.
 */
public class VikaEntity extends GirlEntity {
    private static final EntityDataAccessor<Boolean> DATA_BOSS =
            SynchedEntityData.defineId(VikaEntity.class, EntityDataSerializers.BOOLEAN);

    private final ServerBossEvent bossEvent = new ServerBossEvent(Component.literal("Вика"),
            BossEvent.BossBarColor.PINK, BossEvent.BossBarOverlay.PROGRESS);

    private int boltCooldown = 40;
    private int dashCooldown = 120;
    private int shieldCooldown = 200;
    private int barrageCooldown = 160;
    private int shieldTicks;
    private int dashTicks;
    private int phaseLineStage;

    public VikaEntity(EntityType<? extends VikaEntity> type, Level level) {
        super(type, level, GirlType.VIKA);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_BOSS, false);
    }

    public boolean isBoss() {
        return this.entityData.get(DATA_BOSS);
    }

    @Override
    protected boolean isHostileBoss() {
        return isBoss();
    }

    @Override
    protected boolean targetsPlayers() {
        return isBoss();
    }

    /** Called by the portal. Resets her to full 50 HP and switches the boss logic on. */
    public void startBossFight() {
        this.entityData.set(DATA_BOSS, true);
        setFollowing(false);
        setOwner(null);
        setHealth(getMaxHealth());
        this.phaseLineStage = 0;
        this.setCustomName(Component.literal("Вика"));
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.addGoal(2, new CombatGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 0, true, false,
                e -> isBoss()));
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Boss", isBoss());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.entityData.set(DATA_BOSS, tag.getBoolean("Boss"));
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        if (isBoss()) {
            this.bossEvent.addPlayer(player);
        }
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        this.bossEvent.removePlayer(player);
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (this.boltCooldown > 0) this.boltCooldown--;
        if (this.dashCooldown > 0) this.dashCooldown--;
        if (this.shieldCooldown > 0) this.shieldCooldown--;
        if (this.barrageCooldown > 0) this.barrageCooldown--;
        if (this.shieldTicks > 0 && --this.shieldTicks == 0) {
            setShielded(false);
        }
        if (this.dashTicks > 0) {
            this.dashTicks--;
            dashDamage();
        }
        if (isBoss()) {
            this.bossEvent.setProgress(getHealth() / getMaxHealth());
            if (this.tickCount % 20 == 0) {
                for (ServerPlayer p : ((ServerLevel) this.level()).getPlayers(sp -> sp.distanceToSqr(this) < 64.0D * 64.0D)) {
                    this.bossEvent.addPlayer(p);
                }
            }
        }
    }

    // ------------------------------------------------------------------ boss defeat

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!this.level().isClientSide && isBoss() && !isShielded()
                && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)
                && getHealth() - amount <= 1.0F) {
            Entity attacker = source.getEntity();
            defeated(attacker instanceof Player p ? p : this.level().getNearestPlayer(this, 32.0D));
            return false;
        }
        boolean result = super.hurt(source, amount);
        if (result && isBoss() && !this.level().isClientSide) {
            announcePhase();
        }
        return result;
    }

    private void announcePhase() {
        float ratio = getHealth() / getMaxHealth();
        int stage = ratio < 0.34F ? 2 : ratio < 0.67F ? 1 : 0;
        if (stage > this.phaseLineStage) {
            this.phaseLineStage = stage;
            String line = stage == 1 ? "Неплохо! Но это ещё только разминка!" : "Хватит играть! Теперь по-настоящему!";
            for (ServerPlayer p : ((ServerLevel) this.level()).getPlayers(sp -> sp.distanceToSqr(this) < 48.0D * 48.0D)) {
                say(p, line);
            }
        }
    }

    private void defeated(Player winner) {
        this.entityData.set(DATA_BOSS, false);
        this.bossEvent.removeAllPlayers();
        setTarget(null);
        setShielded(false);
        setHealth(getMaxHealth() * 0.5F);
        if (winner != null) {
            setOwner(winner);
            setFollowing(true);
        }
        if (this.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.HEART, getX(), getY() + 1.5D, getZ(), 14, 0.5D, 0.5D, 0.5D, 0.05D);
            for (ServerPlayer p : sl.getPlayers(sp -> sp.distanceToSqr(this) < 48.0D * 48.0D)) {
                say(p, "Ха... ты сильнее, чем я думала. Ладно, твоя взяла. Теперь я с тобой — пока не надоест!");
            }
        }
    }

    // ------------------------------------------------------------------ abilities

    private Vec3 aimAt(LivingEntity target) {
        return new Vec3(target.getX() - getX(), target.getEyeY() - (getY() + 1.4D), target.getZ() - getZ()).normalize();
    }

    private void fireBolt(Vec3 dir) {
        VikaBolt bolt = new VikaBolt(ModEntities.VIKA_BOLT.get(), this, this.level());
        bolt.setPos(getX() + dir.x * 0.8D, getY() + 1.4D + dir.y * 0.8D, getZ() + dir.z * 0.8D);
        bolt.shoot(dir.x, dir.y, dir.z, 1.4F, 0.5F);
        this.level().addFreshEntity(bolt);
    }

    void castBolt(LivingEntity target) {
        this.swing(net.minecraft.world.InteractionHand.MAIN_HAND);
        fireBolt(aimAt(target));
        this.level().playSound(null, blockPosition(), SoundEvents.EVOKER_CAST_SPELL, SoundSource.HOSTILE, 1.0F, 1.2F);
        this.boltCooldown = isBoss() ? 30 : 45;
    }

    void castBarrage(LivingEntity target) {
        this.swing(net.minecraft.world.InteractionHand.MAIN_HAND);
        Vec3 dir = aimAt(target);
        for (int i = -3; i <= 3; i++) {
            fireBolt(dir.yRot((float) Math.toRadians(i * 11.0D)));
        }
        this.level().playSound(null, blockPosition(), SoundEvents.EVOKER_PREPARE_ATTACK, SoundSource.HOSTILE, 1.2F, 0.9F);
        this.barrageCooldown = isBoss() ? 160 : 240;
    }

    void castDash(LivingEntity target) {
        Vec3 d = new Vec3(target.getX() - getX(), 0.0D, target.getZ() - getZ()).normalize();
        setDeltaMovement(d.x * 1.5D, 0.2D, d.z * 1.5D);
        this.hasImpulse = true;
        this.dashTicks = 8;
        this.level().playSound(null, blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.HOSTILE, 1.0F, 1.5F);
        this.dashCooldown = isBoss() ? 100 : 160;
    }

    void castShield() {
        setShielded(true);
        this.shieldTicks = 80;
        this.shieldCooldown = isBoss() ? 320 : 480;
        this.level().playSound(null, blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.HOSTILE, 1.0F, 1.6F);
    }

    private void dashDamage() {
        List<LivingEntity> hit = this.level().getEntitiesOfClass(LivingEntity.class,
                getBoundingBox().inflate(0.7D), e -> e != this && !(e instanceof GirlEntity)
                        && e != getOwnerPlayer() && e.isAlive());
        for (LivingEntity e : hit) {
            if (e instanceof Player && !isBoss()) {
                continue;
            }
            e.hurt(this.damageSources().mobAttack(this), 6.0F);
            e.knockback(0.8D, getX() - e.getX(), getZ() - e.getZ());
        }
    }

    /** Picks abilities. Runs next to melee, never blocks movement goals. */
    static class CombatGoal extends Goal {
        private final VikaEntity vika;

        CombatGoal(VikaEntity vika) {
            this.vika = vika;
        }

        @Override
        public boolean canUse() {
            LivingEntity t = vika.getTarget();
            return t != null && t.isAlive() && !vika.isSleeping();
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void tick() {
            LivingEntity t = vika.getTarget();
            if (t == null) {
                return;
            }
            vika.getLookControl().setLookAt(t, 30.0F, 30.0F);
            double d = vika.distanceToSqr(t);
            boolean weak = vika.getHealth() < vika.getMaxHealth() * 0.5F;
            if (!vika.isShielded() && vika.shieldCooldown <= 0 && (weak || vika.hurtTime > 0 && vika.random.nextInt(6) == 0)) {
                vika.castShield();
            } else if (vika.barrageCooldown <= 0 && d > 25.0D && d < 24.0D * 24.0D && vika.hasLineOfSight(t)) {
                vika.castBarrage(t);
            } else if (vika.dashCooldown <= 0 && d > 36.0D && d < 14.0D * 14.0D) {
                vika.castDash(t);
            } else if (vika.boltCooldown <= 0 && d > 9.0D && d < 24.0D * 24.0D && vika.hasLineOfSight(t)) {
                vika.castBolt(t);
            }
        }
    }
}
