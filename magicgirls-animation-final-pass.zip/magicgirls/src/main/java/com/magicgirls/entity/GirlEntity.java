package com.magicgirls.entity;

import com.magicgirls.client.ClientHooks;
import com.magicgirls.setup.GirlConfig;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;
import java.util.Optional;
import java.util.UUID;

public class GirlEntity extends PathfinderMob {
    public static final int STATE_NONE = 0;
    public static final int STATE_HUG = 1;
    public static final int STATE_WAKE = 2;
    public static final int STATE_GAUNTLET = 3;
    public static final int STATE_PET = 4;
    public static final int STATE_GREETING = 5;
    public static final int STATE_BYE = 6;

    public static final int ACTION_TALK = 0;
    public static final int ACTION_HUG = 1;
    public static final int ACTION_FOLLOW = 2;
    public static final int ACTION_STOP = 3;
    public static final int ACTION_WAIT = 4;
    public static final int ACTION_SLEEP = 5;
    public static final int ACTION_PET = 6;
    public static final int ACTION_BYE = 7;

    private static final EntityDataAccessor<Integer> DATA_STATE =
            SynchedEntityData.defineId(GirlEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_FOLLOW =
            SynchedEntityData.defineId(GirlEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_SHIELD =
            SynchedEntityData.defineId(GirlEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Optional<UUID>> DATA_OWNER =
            SynchedEntityData.defineId(GirlEntity.class, EntityDataSerializers.OPTIONAL_UUID);

    protected final GirlType girl;
    private int stateTimer;
    private int talkCooldown;

    public GirlEntity(EntityType<? extends GirlEntity> type, Level level, GirlType girl) {
        super(type, level);
        this.girl = girl;
        this.setPersistenceRequired();
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder attributes(GirlType t) {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, t.maxHealth)
                .add(Attributes.MOVEMENT_SPEED, t == GirlType.VIKA ? 0.30D : 0.27D)
                .add(Attributes.ATTACK_DAMAGE, t.attack)
                .add(Attributes.ARMOR, t.armor)
                .add(Attributes.FOLLOW_RANGE, 32.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, t == GirlType.VIKA ? 0.5D : 0.1D);
    }

    public GirlType getGirlType() {
        return girl;
    }

    // ------------------------------------------------------------------ data

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_STATE, STATE_NONE);
        this.entityData.define(DATA_FOLLOW, false);
        this.entityData.define(DATA_SHIELD, false);
        this.entityData.define(DATA_OWNER, Optional.empty());
    }

    public int getState() {
        return this.entityData.get(DATA_STATE);
    }

    protected void setState(int state, int ticks) {
        this.entityData.set(DATA_STATE, state);
        this.stateTimer = ticks;
    }

    public boolean isFollowing() {
        return this.entityData.get(DATA_FOLLOW);
    }

    public void setFollowing(boolean value) {
        this.entityData.set(DATA_FOLLOW, value);
    }

    public boolean isShielded() {
        return this.entityData.get(DATA_SHIELD);
    }

    public void setShielded(boolean value) {
        this.entityData.set(DATA_SHIELD, value);
    }

    @Nullable
    public Player getOwnerPlayer() {
        UUID id = this.entityData.get(DATA_OWNER).orElse(null);
        return id == null ? null : this.level().getPlayerByUUID(id);
    }

    public void setOwner(@Nullable Player player) {
        this.entityData.set(DATA_OWNER, Optional.ofNullable(player == null ? null : player.getUUID()));
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Following", isFollowing());
        this.entityData.get(DATA_OWNER).ifPresent(id -> tag.putUUID("Owner", id));
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setFollowing(tag.getBoolean("Following"));
        if (tag.hasUUID("Owner")) {
            this.entityData.set(DATA_OWNER, Optional.of(tag.getUUID("Owner")));
        }
    }

    // ------------------------------------------------------------------ AI

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new SleepInBedGoal(this));
        this.goalSelector.addGoal(3, new MeleeAttackGoal(this, 1.15D, true));
        this.goalSelector.addGoal(4, new FollowOwnerGoal(this));
        this.goalSelector.addGoal(6, new IdleStrollGoal(this));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Monster.class, 10, true, false,
                e -> isFollowing() && !isSleeping()));
    }

    /** Companions never turn on players; only the Vika boss is allowed to target them. */
    @Override
    public void setTarget(@Nullable LivingEntity target) {
        if (target instanceof Player && !targetsPlayers()) {
            target = null;
        }
        super.setTarget(target);
    }

    protected boolean targetsPlayers() {
        return false;
    }

    /** True while the entity must not be talked to (Vika during the boss fight). */
    protected boolean isHostileBoss() {
        return false;
    }

    @Override
    protected boolean isImmobile() {
        return super.isImmobile() || isSleeping() || getState() == STATE_HUG;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public int getMaxSpawnClusterSize() {
        return 1;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            clientTick();
            return;
        }
        if (this.stateTimer > 0 && --this.stateTimer == 0) {
            this.entityData.set(DATA_STATE, STATE_NONE);
        }
        if (this.talkCooldown > 0) {
            this.talkCooldown--;
        }
        // While Sulfur is being petted, keep the affection effect visible rather
        // than spawning hearts only once when the menu action is selected.
        if (getState() == STATE_PET && this.tickCount % 12 == 0) {
            hearts();
        }
        if (isImmobile()) {
            this.getNavigation().stop();
        }
    }

    protected void clientTick() {
        if (isShielded() && this.tickCount % 3 == 0) {
            double a = this.tickCount * 0.35D;
            for (int i = 0; i < 2; i++) {
                double ang = a + i * Math.PI;
                this.level().addParticle(ParticleTypes.END_ROD,
                        getX() + Math.cos(ang) * 0.9D, getY() + 0.3D + (this.tickCount % 24) / 16.0D,
                        getZ() + Math.sin(ang) * 0.9D, 0.0D, 0.0D, 0.0D);
            }
        }
    }

    public static boolean isNight(Level level) {
        long t = level.getDayTime() % 24000L;
        return t >= 13000L && t <= 23000L;
    }

    // ------------------------------------------------------------------ interaction

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND || isHostileBoss()) {
            return InteractionResult.PASS;
        }
        if (this.level().isClientSide) {
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.openMenu(this));
        }
        return InteractionResult.sidedSuccess(this.level().isClientSide);
    }

    /** Server side: handles a menu button. */
    public void handleAction(ServerPlayer player, int action) {
        if (isHostileBoss()) {
            return;
        }
        switch (action) {
            case ACTION_TALK:
                if (isSleeping()) {
                    wakeUp();
                    say(player, GirlType.Cat.WAKE);
                } else if (getHealth() < getMaxHealth() * 0.4F) {
                    say(player, GirlType.Cat.HURT);
                } else if (isNight(this.level()) && this.random.nextInt(3) == 0) {
                    say(player, GirlType.Cat.NIGHT);
                } else {
                    say(player, GirlType.Cat.TALK);
                }
                setState(STATE_GREETING, 28);
                break;
            case ACTION_HUG:
                if (isSleeping()) {
                    wakeUp();
                }
                faceTowards(player);
                setState(STATE_HUG, 50);
                player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 0));
                hearts();
                say(player, GirlType.Cat.HUG);
                break;
            case ACTION_FOLLOW:
                if (isSleeping()) {
                    wakeUp();
                }
                setOwner(player);
                setFollowing(true);
                say(player, GirlType.Cat.FOLLOW);
                break;
            case ACTION_STOP:
                setFollowing(false);
                this.getNavigation().stop();
                say(player, GirlType.Cat.STOP);
                break;
            case ACTION_WAIT:
                setFollowing(false);
                this.getNavigation().stop();
                say(player, GirlType.Cat.STOP);
                break;
            case ACTION_SLEEP:
                setFollowing(false);
                this.getNavigation().stop();
                BlockPos sleepBed = findFreeBed(this, 8);
                if (sleepBed != null) {
                    this.startSleeping(sleepBed);
                    say(player, "Хорошо, я немного отдохну.");
                } else {
                    say(player, "Поблизости нет свободной кровати.");
                }
                break;
            case ACTION_PET:
                if (girl != GirlType.SULFUR) break;
                if (isSleeping()) wakeUp();
                faceTowards(player);
                setState(STATE_PET, 1200); // Keep petting active for up to 60 seconds while the player interacts.
                hearts();
                say(player, "Хи-хи! Мне приятно, когда меня гладят!");
                break;
            case ACTION_BYE:
                setFollowing(false);
                setOwner(null);
                this.getNavigation().stop();
                setState(STATE_BYE, 32);
                say(player, GirlType.Cat.BYE);
                break;
            default:
                break;
        }
    }

    private void faceTowards(Player p) {
        double dx = p.getX() - getX();
        double dz = p.getZ() - getZ();
        float yaw = (float) (Mth.atan2(dz, dx) * (180.0D / Math.PI)) - 90.0F;
        setYRot(yaw);
        this.yBodyRot = yaw;
        this.yHeadRot = yaw;
    }

    private void hearts() {
        if (this.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.HEART, getX(), getY() + 1.6D, getZ(), 6, 0.4D, 0.3D, 0.4D, 0.02D);
        }
    }

    public void say(Player player, GirlType.Cat cat) {
        String[] pool = girl.lines(cat);
        String line = pool[this.random.nextInt(pool.length)];
        say(player, line);
    }

    public void say(Player player, String line) {
        player.sendSystemMessage(Component.literal(girl.displayName)
                .withStyle(Style.EMPTY.withColor(girl.color).withBold(true))
                .append(Component.literal(": " + line).withStyle(ChatFormatting.WHITE)));
    }

    /** Called when a player lies down in a bed close to this girl. */
    public void reactToPlayerBed(Player player) {
        if (isSleeping() || isHostileBoss()) {
            return;
        }
        if (this.talkCooldown <= 0) {
            say(player, GirlType.Cat.BED);
            this.talkCooldown = 100;
        }
        if (isFollowing() && player.getUUID().equals(this.entityData.get(DATA_OWNER).orElse(null))) {
            BlockPos bed = findFreeBed(this, 8);
            if (bed != null) {
                this.getNavigation().stop();
                this.startSleeping(bed);
            }
        }
    }

    public void wakeUp() {
        if (isSleeping()) {
            this.stopSleeping();
            setState(STATE_WAKE, 40);
        }
    }

    @Nullable
    public static BlockPos findFreeBed(GirlEntity g, int radius) {
        BlockPos origin = g.blockPosition();
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        for (BlockPos pos : BlockPos.betweenClosed(origin.offset(-radius, -3, -radius), origin.offset(radius, 3, radius))) {
            BlockState state = g.level().getBlockState(pos);
            if (state.getBlock() instanceof BedBlock && !state.getValue(BedBlock.OCCUPIED)) {
                double d = pos.distSqr(origin);
                if (d < bestDist) {
                    bestDist = d;
                    best = pos.immutable();
                }
            }
        }
        return best;
    }

    // ------------------------------------------------------------------ damage / sounds

    /** Sulfur's oversized gauntlets deliver a heavier impact and a visible hit spark. */
    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hit = super.doHurtTarget(target);
        if (hit && girl == GirlType.SULFUR && target instanceof LivingEntity living) {
            // Heavy gauntlet strike: briefly raise both oversized fists for a readable attack pose.
            setState(STATE_GAUNTLET, 12);
            double radians = this.getYRot() * (Math.PI / 180.0D);
            living.knockback(1.15D, Math.sin(radians), -Math.cos(radians));
            if (this.level() instanceof ServerLevel server) {
                server.sendParticles(ParticleTypes.CRIT,
                        living.getX(), living.getY() + living.getBbHeight() * 0.55D, living.getZ(),
                        16, 0.32D, 0.32D, 0.32D, 0.16D);
            }
        }
        return hit;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (isShielded() && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            if (this.level() instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.ENCHANTED_HIT, getX(), getY() + 1.0D, getZ(), 8, 0.4D, 0.5D, 0.4D, 0.1D);
            }
            return false;
        }
        boolean result = super.hurt(source, amount);
        if (result && !this.level().isClientSide) {
            if (isSleeping()) {
                wakeUp();
            }
            Entity attacker = source.getEntity();
            if (this.talkCooldown <= 0 && !isHostileBoss()) {
                Player target = attacker instanceof Player p ? p : getOwnerPlayer();
                if (target != null && target.distanceToSqr(this) < 256.0D) {
                    say(target, GirlType.Cat.HURT);
                    this.talkCooldown = 80;
                }
            }
        }
        return result;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.PLAYER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.PLAYER_DEATH;
    }

    // ------------------------------------------------------------------ goals

    /** Walks around only while not following an owner. */
    static class IdleStrollGoal extends WaterAvoidingRandomStrollGoal {
        private final GirlEntity girl;

        IdleStrollGoal(GirlEntity girl) {
            super(girl, 0.8D);
            this.girl = girl;
        }

        @Override
        public boolean canUse() {
            return !girl.isFollowing() && !girl.isImmobile() && super.canUse();
        }
    }

    static class FollowOwnerGoal extends Goal {
        private final GirlEntity girl;
        private Player owner;
        private int recalc;

        FollowOwnerGoal(GirlEntity girl) {
            this.girl = girl;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            if (!girl.isFollowing() || girl.isImmobile() || girl.getTarget() != null) {
                return false;
            }
            Player p = girl.getOwnerPlayer();
            if (p == null || p.isSpectator()) {
                return false;
            }
            this.owner = p;
            return girl.distanceToSqr(p) > 9.0D;
        }

        @Override
        public boolean canContinueToUse() {
            return girl.isFollowing() && !girl.isImmobile() && girl.getTarget() == null && owner != null
                    && owner.isAlive() && girl.distanceToSqr(owner) > 4.0D;
        }

        @Override
        public void start() {
            recalc = 0;
        }

        @Override
        public void stop() {
            girl.setSprinting(false);
            girl.getNavigation().stop();
            owner = null;
        }

        @Override
        public void tick() {
            girl.getLookControl().setLookAt(owner, 10.0F, girl.getMaxHeadXRot());
            double distSqr = girl.distanceToSqr(owner);
            int tp = GirlConfig.FOLLOW_TELEPORT_DISTANCE.get();
            if (distSqr > (double) (tp * tp)) {
                tryTeleport();
                return;
            }
            girl.setSprinting(distSqr > 64.0D);
            if (--recalc <= 0) {
                recalc = 10;
                girl.getNavigation().moveTo(owner, distSqr > 64.0D ? 1.35D : 1.0D);
            }
        }

        private void tryTeleport() {
            BlockPos base = owner.blockPosition();
            for (int i = 0; i < 10; i++) {
                int x = base.getX() + girl.random.nextInt(5) - 2;
                int z = base.getZ() + girl.random.nextInt(5) - 2;
                if (Math.abs(x - base.getX()) < 2 && Math.abs(z - base.getZ()) < 2) {
                    continue;
                }
                BlockPos pos = new BlockPos(x, base.getY(), z);
                if (girl.level().getBlockState(pos.below()).isSolid()
                        && girl.level().noCollision(girl, girl.getBoundingBox().move(
                        x + 0.5D - girl.getX(), pos.getY() - girl.getY(), z + 0.5D - girl.getZ()))) {
                    girl.moveTo(x + 0.5D, pos.getY(), z + 0.5D, girl.getYRot(), girl.getXRot());
                    girl.getNavigation().stop();
                    return;
                }
            }
        }
    }

    /** Free girls look for a free bed at night, walk to it and sleep until morning. */
    static class SleepInBedGoal extends Goal {
        private final GirlEntity girl;
        private BlockPos bed;
        private boolean sleeping;
        private int scanDelay;

        SleepInBedGoal(GirlEntity girl) {
            this.girl = girl;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP));
        }

        @Override
        public boolean canUse() {
            if (girl.isFollowing() || girl.getTarget() != null || girl.isHostileBoss()
                    || girl.getState() != STATE_NONE || !isNight(girl.level())) {
                return false;
            }
            if (--scanDelay > 0) {
                return false;
            }
            scanDelay = 60 + girl.random.nextInt(40);
            bed = findFreeBed(girl, 10);
            return bed != null;
        }

        @Override
        public boolean canContinueToUse() {
            return bed != null && !girl.isFollowing() && girl.getTarget() == null && isNight(girl.level());
        }

        @Override
        public void start() {
            sleeping = false;
            girl.getNavigation().moveTo(bed.getX() + 0.5D, bed.getY() + 0.5625D, bed.getZ() + 0.5D, 0.9D);
        }

        @Override
        public void tick() {
            if (sleeping) {
                return;
            }
            double d = girl.distanceToSqr(bed.getX() + 0.5D, bed.getY() + 0.5D, bed.getZ() + 0.5D);
            if (d < 2.5D) {
                BlockState st = girl.level().getBlockState(bed);
                if (st.getBlock() instanceof BedBlock && !st.getValue(BedBlock.OCCUPIED)) {
                    girl.getNavigation().stop();
                    girl.startSleeping(bed);
                    sleeping = true;
                } else {
                    bed = null;
                }
            } else if (girl.getNavigation().isDone()) {
                bed = null;
            }
        }

        @Override
        public void stop() {
            if (sleeping) {
                girl.wakeUp();
            }
            sleeping = false;
            bed = null;
        }
    }
}
