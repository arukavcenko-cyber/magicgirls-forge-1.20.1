package com.magicgirls.block;

import com.magicgirls.entity.VikaEntity;
import com.magicgirls.setup.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * "Vika portal": a ritual block that only works in the Nether.
 * Needs crying obsidian on all four horizontal sides, two free blocks above, and a Nether Star
 * used on it. The ritual consumes the block, the ring and the star and opens a rift: Vika appears
 * as a 50 HP boss.
 */
public class VikaPortalBlock extends Block {
    public VikaPortalBlock(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        ItemStack held = player.getItemInHand(hand);
        if (!held.is(Items.NETHER_STAR)) {
            if (!level.isClientSide) {
                player.displayClientMessage(Component.literal(
                        "Портал Вики отзывается на звезду Незера. Нужен слезящийся обсидиан со всех четырёх сторон."), true);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (level.dimension() != Level.NETHER) {
            player.displayClientMessage(Component.literal("Портал работает только в Незере."), true);
            return InteractionResult.CONSUME;
        }
        for (Direction d : Direction.Plane.HORIZONTAL) {
            if (!level.getBlockState(pos.relative(d)).is(Blocks.CRYING_OBSIDIAN)) {
                player.displayClientMessage(Component.literal(
                        "Не хватает слезящегося обсидиана с одной из четырёх сторон."), true);
                return InteractionResult.CONSUME;
            }
        }
        if (!level.getBlockState(pos.above()).isAir() || !level.getBlockState(pos.above(2)).isAir()) {
            player.displayClientMessage(Component.literal("Над порталом нужно два свободных блока."), true);
            return InteractionResult.CONSUME;
        }
        ServerLevel sl = (ServerLevel) level;
        if (!player.getAbilities().instabuild) {
            held.shrink(1);
        }
        for (Direction d : Direction.Plane.HORIZONTAL) {
            sl.destroyBlock(pos.relative(d), false);
        }
        sl.removeBlock(pos, false);

        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(sl);
        if (bolt != null) {
            bolt.moveTo(Vec3.atBottomCenterOf(pos));
            bolt.setVisualOnly(true);
            sl.addFreshEntity(bolt);
        }
        VikaEntity vika = ModEntities.VIKA.get().create(sl);
        if (vika != null) {
            vika.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, player.getYRot() + 180.0F, 0.0F);
            vika.startBossFight();
            sl.addFreshEntity(vika);
            for (ServerPlayer p : sl.getPlayers(sp -> sp.distanceToSqr(vika) < 48.0D * 48.0D)) {
                vika.say(p, "Кто посмел открыть мой портал?! Что ж... докажи, что ты достоин!");
            }
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (random.nextInt(3) == 0) {
            level.addParticle(ParticleTypes.REVERSE_PORTAL,
                    pos.getX() + random.nextDouble(), pos.getY() + 1.0D, pos.getZ() + random.nextDouble(),
                    0.0D, 0.08D, 0.0D);
        }
    }
}
