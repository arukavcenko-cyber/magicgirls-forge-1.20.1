package com.magicgirls.command;

import com.magicgirls.entity.GirlEntity;
import com.magicgirls.entity.GirlType;
import com.magicgirls.entity.VikaEntity;
import com.magicgirls.setup.ModEntities;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.coordinates.Vec3Argument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;

import java.util.Arrays;

/**
 * /magicgirls summon <beze|kiwi|azur|magenta|vika> [pos]
 * /magicgirls summonall
 * /magicgirls vikaboss [pos]
 */
public final class GirlCommands {
    private GirlCommands() {}

    public static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("magicgirls").requires(s -> s.hasPermission(2))
                .then(Commands.literal("summon")
                        .then(Commands.argument("girl", StringArgumentType.word())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(
                                        Arrays.stream(GirlType.values()).map(t -> t.id), b))
                                .executes(c -> summon(c.getSource(),
                                        StringArgumentType.getString(c, "girl"), c.getSource().getPosition(), false))
                                .then(Commands.argument("pos", Vec3Argument.vec3())
                                        .executes(c -> summon(c.getSource(), StringArgumentType.getString(c, "girl"),
                                                Vec3Argument.getVec3(c, "pos"), false)))))
                .then(Commands.literal("summonall")
                        .executes(c -> {
                            int n = 0;
                            Vec3 base = c.getSource().getPosition();
                            double step = 2.0D;
                            for (GirlType t : GirlType.values()) {
                                n += summon(c.getSource(), t.id, base.add(step * (t.ordinal() - 2), 0, 2.0D), false);
                            }
                            return n;
                        }))
                .then(Commands.literal("vikaboss")
                        .executes(c -> summon(c.getSource(), "vika", c.getSource().getPosition(), true))
                        .then(Commands.argument("pos", Vec3Argument.vec3())
                                .executes(c -> summon(c.getSource(), "vika",
                                        Vec3Argument.getVec3(c, "pos"), true)))));
    }

    private static int summon(CommandSourceStack src, String id, Vec3 pos, boolean boss) {
        GirlType type = GirlType.byId(id);
        if (type == null) {
            src.sendFailure(Component.literal("Неизвестный персонаж: " + id
                    + " (beze, kiwi, azur, magenta, vika)"));
            return 0;
        }
        ServerLevel level = src.getLevel();
        GirlEntity girl = ModEntities.of(type).create(level);
        if (girl == null) {
            return 0;
        }
        girl.moveTo(pos.x, pos.y, pos.z, src.getRotation().y + 180.0F, 0.0F);
        level.addFreshEntity(girl);
        if (boss && girl instanceof VikaEntity vika) {
            vika.startBossFight();
        }
        src.sendSuccess(() -> Component.literal("Призвана: " + type.displayName + (boss ? " (босс)" : "")), true);
        return 1;
    }
}
