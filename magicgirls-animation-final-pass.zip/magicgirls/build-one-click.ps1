$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root
$Tools = Join-Path $Root '.tools'
New-Item -ItemType Directory -Force -Path $Tools | Out-Null

function Get-ZipTool($Url, $ZipPath, $Destination, $ExpectedFolder) {
    if (-not (Test-Path (Join-Path $Destination $ExpectedFolder))) {
        Write-Host "Скачиваю $ExpectedFolder..." -ForegroundColor Cyan
        Invoke-WebRequest -Uri $Url -OutFile $ZipPath
        Expand-Archive -LiteralPath $ZipPath -DestinationPath $Destination -Force
        Remove-Item $ZipPath -Force
    }
}

$JdkDir = Join-Path $Tools 'jdk-17'
if (-not (Test-Path (Join-Path $JdkDir 'bin\java.exe'))) {
    $JdkZip = Join-Path $Tools 'jdk17.zip'
    $JdkUrl = 'https://api.adoptium.net/v3/binary/latest/17/ga/windows/x64/jdk/hotspot/normal/eclipse'
    Write-Host 'Скачиваю Java 17 (это может занять несколько минут)...' -ForegroundColor Cyan
    Invoke-WebRequest -Uri $JdkUrl -OutFile $JdkZip
    $TempJdk = Join-Path $Tools 'jdk-temp'
    New-Item -ItemType Directory -Force -Path $TempJdk | Out-Null
    Expand-Archive -LiteralPath $JdkZip -DestinationPath $TempJdk -Force
    $Extracted = Get-ChildItem $TempJdk -Directory | Select-Object -First 1
    if (-not $Extracted) { throw 'Не удалось распаковать Java 17.' }
    if (Test-Path $JdkDir) { Remove-Item $JdkDir -Recurse -Force }
    Move-Item $Extracted.FullName $JdkDir
    Remove-Item $TempJdk -Recurse -Force
    Remove-Item $JdkZip -Force
}

$GradleDir = Join-Path $Tools 'gradle-8.1.1'
if (-not (Test-Path (Join-Path $GradleDir 'bin\gradle.bat'))) {
    $GradleZip = Join-Path $Tools 'gradle-8.1.1-bin.zip'
    $GradleUrl = 'https://services.gradle.org/distributions/gradle-8.1.1-bin.zip'
    Write-Host 'Скачиваю Gradle 8.1.1...' -ForegroundColor Cyan
    Invoke-WebRequest -Uri $GradleUrl -OutFile $GradleZip
    Expand-Archive -LiteralPath $GradleZip -DestinationPath $Tools -Force
    Remove-Item $GradleZip -Force
}

$env:JAVA_HOME = $JdkDir
$env:Path = (Join-Path $JdkDir 'bin') + ';' + (Join-Path $GradleDir 'bin') + ';' + $env:Path
Write-Host "Java:" -ForegroundColor Green
& (Join-Path $JdkDir 'bin\java.exe') -version
Write-Host 'Запускаю сборку Forge 1.20.1...' -ForegroundColor Cyan
& (Join-Path $GradleDir 'bin\gradle.bat') --no-daemon build
if ($LASTEXITCODE -ne 0) { throw 'Сборка завершилась с ошибкой. Скопируй текст ошибки из этого окна.' }
$Jar = Get-ChildItem (Join-Path $Root 'build\libs') -Filter '*.jar' | Where-Object { $_.Name -notmatch '-sources|-javadoc' } | Select-Object -First 1
if (-not $Jar) { throw 'Gradle завершился, но JAR не найден в build\libs.' }
Write-Host ''
Write-Host 'ГОТОВО! Собранный мод:' -ForegroundColor Green
Write-Host $Jar.FullName -ForegroundColor Yellow
Write-Host 'Скопируй этот JAR в папку .minecraft\mods. Нужен Forge 1.20.1.' -ForegroundColor Green
