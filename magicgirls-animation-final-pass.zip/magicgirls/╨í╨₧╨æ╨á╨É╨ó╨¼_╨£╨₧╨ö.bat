@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Magic Girls - автоматическая сборка Forge 1.20.1
echo Нужен интернет для загрузки Java, Gradle и библиотек Forge.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build-one-click.ps1"
if errorlevel 1 (
  echo.
  echo Сборка не удалась. Сфотографируй или скопируй ошибку.
) else (
  echo.
  echo JAR собран. Он находится в папке build\libs.
)
pause
