@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "GRADLE_VERSION=8.1.1"
set "GRADLE_HOME_LOCAL=%CD%\.tools\gradle-%GRADLE_VERSION%"
set "GRADLE_EXE=%GRADLE_HOME_LOCAL%\bin\gradle.bat"

echo ================================================
echo Magic Girls - Forge 1.20.1 / Forge 47.2.0
echo ================================================

where java >nul 2>nul
if errorlevel 1 (
  echo ERROR: Java is not installed. Install JDK 17 first.
  pause
  exit /b 1
)
java -version

if not exist "%GRADLE_EXE%" (
  where gradle >nul 2>nul
  if not errorlevel 1 (
    set "GRADLE_EXE=gradle"
  ) else (
    echo Gradle %GRADLE_VERSION% not found. Downloading it now...
    if not exist ".tools" mkdir ".tools"
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $zip=Join-Path (Get-Location) 'gradle-%GRADLE_VERSION%-bin.zip'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile $zip; Expand-Archive -LiteralPath $zip -DestinationPath '.tools' -Force; Remove-Item $zip"
    if errorlevel 1 (
      echo ERROR: Could not download Gradle. Check internet access and try again.
      pause
      exit /b 1
    )
  )
)

"%GRADLE_EXE%" --version
if errorlevel 1 exit /b 1
"%GRADLE_EXE%" --no-daemon build
if errorlevel 1 (
  echo.
  echo BUILD FAILED. Copy the complete error output.
  pause
  exit /b 1
)

echo.
echo BUILD SUCCESSFUL. Check build\libs\ for the mod JAR.
dir build\libs\*.jar
pause
