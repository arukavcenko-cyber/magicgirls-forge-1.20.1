#!/usr/bin/env python3
"""
Generates, from ONE shared part specification:
  * src/main/java/com/magicgirls/client/model/GirlModels.java  (LayerDefinitions)
  * textures/entity/<id>.png, <id>_happy.png, <id>_sleep.png
  * textures/block/vika_portal.png
Because geometry and UV painting come from the same data, the UV layout can never drift
away from the Java model.  Run:  python3 tools/gen_assets.py
"""
import os
from PIL import Image

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
RES = os.path.join(ROOT, 'src/main/resources/assets/magicgirls')
JAVA = os.path.join(ROOT, 'src/main/java/com/magicgirls/client/model/GirlModels.java')
TEXSZ = 256


def C(h):
    return tuple(int(h[i:i + 2], 16) for i in (1, 3, 5))


def clamp(v):
    return max(0, min(255, int(v)))


def mul(col, f):
    return tuple(clamp(x * f) for x in col)


def mix(a, b, t):
    return tuple(clamp(a[i] * (1 - t) + b[i] * t) for i in range(3))


def hsh(x, y, s):
    h = (x * 374761393 + y * 668265263 + s * 2147483647) & 0xFFFFFFFF
    h = ((h ^ (h >> 13)) * 1274126177) & 0xFFFFFFFF
    return ((h ^ (h >> 16)) & 255) / 255.0


FACE_F = {'top': 1.12, 'bottom': 0.62, 'west': 0.88, 'north': 1.0, 'east': 0.82, 'south': 0.9}


class Part:
    def __init__(self, name, parent, piv, cube, col, rot, kind, bands, infl, seed):
        self.name, self.parent, self.piv, self.cube = name, parent, piv, cube
        self.col, self.rot, self.kind, self.bands, self.infl, self.seed = col, rot, kind, bands, infl, seed
        self.w, self.h, self.d = cube[3], cube[4], cube[5]
        self.u = self.v = 0

    def color_at(self, frac):
        if not self.bands:
            return self.col
        out = self.bands[0][1]
        for start, color in self.bands:
            if frac + 1e-6 >= start:
                out = color
        return out


class Char:
    def __init__(self, cid):
        self.id = cid
        self.parts = []
        self.face = {}

    def add(self, name, parent, piv, cube, col=None, rot=(0, 0, 0), kind='cloth', bands=None, infl=0.0):
        assert all(isinstance(x, int) for x in cube[3:]), (name, cube)
        assert not any(p.name == name for p in self.parts), name
        self.parts.append(Part(name, parent, piv, cube, col, rot, kind, bands, infl, len(self.parts) * 31 + 7))

    def path(self, p):
        chain = [p.name]
        par = p.parent
        while par:
            q = next(x for x in self.parts if x.name == par)
            chain.append(q.name)
            par = q.parent
        return '/'.join(reversed(chain))


def pack(ch):
    pad = 1
    items = sorted(ch.parts, key=lambda p: (-(p.d + p.h), -(2 * p.d + 2 * p.w)))
    x = y = rowh = 0
    for p in items:
        bw, bh = 2 * p.d + 2 * p.w, p.d + p.h
        if x + bw > TEXSZ:
            x, y, rowh = 0, y + rowh + pad, 0
        p.u, p.v = x, y
        x += bw + pad
        rowh = max(rowh, bh)
    assert y + rowh <= TEXSZ, 'texture overflow for ' + ch.id + ' needs more than %d' % TEXSZ


def shade(p, base, face, i, j, fw, fh, gx, gy):
    n = hsh(gx, gy, p.seed)
    k = p.kind
    f = FACE_F[face]
    if k == 'skin':
        f *= 0.97 + 0.06 * n
    elif k == 'hair':
        f *= 0.84 + 0.30 * hsh(gx, 0, p.seed + 7)
        if face in ('north', 'south', 'east', 'west'):
            f *= 1.12 - 0.22 * (j / max(1, fh - 1))
        if n > 0.93:
            f *= 1.28
    elif k == 'glow':
        f = 1.05 + 0.25 * (n - 0.5)
    elif k == 'metal':
        f *= 0.95 + 0.10 * n
    else:
        f *= 0.95 + 0.10 * n
    col = mul(base, f)
    if k in ('cloth', 'metal', 'glow') and (i in (0, fw - 1) or j in (0, fh - 1)):
        col = mul(col, 0.88)
    return col


def paint_part(img, p):
    w, h, d, u, v = p.w, p.h, p.d, p.u, p.v
    regions = {
        'top': (u + d, v, w, d), 'bottom': (u + d + w, v, w, d),
        'west': (u, v + d, d, h), 'north': (u + d, v + d, w, h),
        'east': (u + d + w, v + d, d, h), 'south': (u + 2 * d + w, v + d, w, h),
    }
    for face, (x0, y0, fw, fh) in regions.items():
        for j in range(fh):
            for i in range(fw):
                frac = 0.0 if face == 'top' else 1.0 if face == 'bottom' else (j + 0.5) / fh
                col = shade(p, p.color_at(frac), face, i, j, fw, fh, x0 + i, y0 + j)
                img.putpixel((x0 + i, y0 + j), col + (255,))


def paint_face(img, head, face, expr):
    x0, y0 = head.u + head.d, head.v + head.d
    skin, dark, eye = face['skin'], face['dark'], face['eye']
    eyed, hi = mul(eye, 0.55), (255, 255, 255)

    def P(i, j, col):
        img.putpixel((x0 + i, y0 + j), tuple(col) + (255,))

    # clean skin base for the whole 10x10 front
    for j in range(10):
        for i in range(10):
            P(i, j, mul(skin, 0.98 + 0.04 * hsh(i, j, 5)))
    for ex in (1, 6):
        if expr == 'normal':
            for k in range(3):
                P(ex + k, 4, dark)
            if face.get('lid'):
                P(ex, 5, dark)
                P(ex + 2, 5, dark)
                P(ex + 1, 5, eye)
            else:
                P(ex, 5, hi)
                P(ex + 1, 5, eye)
                P(ex + 2, 5, eye)
            P(ex, 6, eyed)
            P(ex + 1, 6, eye)
            P(ex + 2, 6, eyed)
        elif expr == 'happy':
            P(ex + 1, 4, dark)
            P(ex, 5, dark)
            P(ex + 2, 5, dark)
        else:  # sleep
            for k in range(3):
                P(ex + k, 5, dark)
    for bx in (1, 2, 7, 8):
        P(bx, 7, mix(skin, face['blush'], 0.65))
    mouth = face['mouth']
    if expr == 'happy':
        for k in range(3, 7):
            P(k, 8, mouth)
        P(4, 9, (255, 130, 150))
        P(5, 9, (255, 130, 150))
    elif expr == 'sleep':
        P(4, 8, mix(mouth, skin, 0.4))
        P(5, 8, mix(mouth, skin, 0.4))
    else:
        P(4, 8, mouth)
        P(5, 8, mouth)
        if face.get('smirk'):
            P(6, 7, mouth)


def build_texture(ch, expr):
    img = Image.new('RGBA', (TEXSZ, TEXSZ), (0, 0, 0, 0))
    for p in ch.parts:
        paint_part(img, p)
    paint_face(img, next(p for p in ch.parts if p.name == 'head'), ch.face, expr)
    return img


# ----------------------------------------------------------------------------------------
# shared building blocks
# ----------------------------------------------------------------------------------------
def humanoid(ch, skin, torso, arm, leg):
    A = ch.add
    A('head', None, (0, 0, 0), (-5, -10, -5, 10, 10, 10), skin, kind='skin')
    A('body', None, (0, 0, 0), (-4, 0, -2, 8, 10, 4), bands=torso)
    A('right_arm', None, (-5.5, 1.5, 0), (-1.5, -1.5, -1.5, 3, 12, 3), bands=arm)
    A('left_arm', None, (5.5, 1.5, 0), (-1.5, -1.5, -1.5, 3, 12, 3), bands=arm)
    A('right_leg', None, (-2, 10, 0), (-2, 0, -2, 4, 14, 4), bands=leg)
    A('left_leg', None, (2, 10, 0), (-2, 0, -2, 4, 14, 4), bands=leg)


def hair_shell(ch, col, back_len=12, side_len=8, back_w=12):
    A = ch.add
    A('hair_cap', 'head', (0, 0, 0), (-6, -11.5, -5.5, 12, 3, 11), col, kind='hair')
    A('hair_side_r', 'head', (0, 0, 0), (-7, -8.5, -5, 2, side_len, 10), col, kind='hair')
    A('hair_side_l', 'head', (0, 0, 0), (5, -8.5, -5, 2, side_len, 10), col, kind='hair')
    A('hair_back', 'head', (0, 0, 0), (-back_w // 2, -10.5, 5, back_w, back_len, 2), col, kind='hair')


def fringe(ch, col):
    A = ch.add
    A('hair_bang_1', 'head', (0, 0, 0), (-5.5, -10.5, -6.0, 4, 4, 1), col, kind='hair')
    A('hair_bang_2', 'head', (0, 0, 0), (-1.5, -10.5, -6.0, 3, 3, 1), col, kind='hair')
    A('hair_bang_3', 'head', (0, 0, 0), (1.5, -10.5, -6.0, 4, 5, 1), col, kind='hair')
    A('hair_strand_r', 'head', (0, 0, 0), (-5.5, -6.5, -6.0, 1, 5, 1), col, kind='hair')
    A('hair_strand_l', 'head', (0, 0, 0), (4.5, -6.5, -6.0, 1, 5, 1), col, kind='hair')


def bow(ch, prefix, parent, cx, cy, cz, col, knot, w=3, h=3, gap=0.5):
    A = ch.add
    A(prefix + '_loop_r', parent, (0, 0, 0), (cx - gap - w, cy, cz, w, h, 1), col)
    A(prefix + '_loop_l', parent, (0, 0, 0), (cx + gap, cy, cz, w, h, 1), col)
    A(prefix + '_knot', parent, (0, 0, 0), (cx - 1, cy + 0.5, cz - 0.3, 2, 2, 1), knot)


# ----------------------------------------------------------------------------------------
# characters
# ----------------------------------------------------------------------------------------
def beze():
    ch = Char('beze')
    skin, hair, hair2 = C('#F8D7CC'), C('#4B2377'), C('#6B3A9E')
    white, purple, dark, gold = C('#F3E8F4'), C('#5A2E8C'), C('#2E1650'), C('#E5AA3C')
    humanoid(ch, skin,
             torso=[(0, white), (0.55, purple)],
             arm=[(0, white), (0.30, skin), (0.55, dark)],
             leg=[(0, skin), (0.22, purple), (0.78, dark)])
    ch.face = dict(skin=skin, dark=C('#2A1238'), eye=C('#D23CC8'), blush=C('#F08AA8'), mouth=C('#B04070'), smirk=True)
    A = ch.add
    hair_shell(ch, hair, back_len=11, side_len=9)
    fringe(ch, hair)
    A('hair_ahoge', 'head', (0, -11.5, -1), (-0.5, -4, -0.5, 1, 4, 1), hair2, rot=(0, 0, 0.2), kind='hair')
    # curly puffs
    A('hair_curl_r1', 'head', (-7, -4, 0), (-2, 0, -2, 4, 5, 4), hair2, kind='hair')
    A('hair_curl_l1', 'head', (7, -4, 0), (-2, 0, -2, 4, 5, 4), hair2, kind='hair')
    A('hair_curl_r2', 'hair_curl_r1', (0, 5, 0), (-1.5, 0, -1.5, 3, 4, 3), hair, kind='hair')
    A('hair_curl_l2', 'hair_curl_l1', (0, 5, 0), (-1.5, 0, -1.5, 3, 4, 3), hair, kind='hair')
    A('hair_curl_back', 'head', (0, 1, 6), (-5, 0, -1, 10, 5, 3), hair2, kind='hair')
    # gold ram-like horns
    for s, nm in ((-1, 'r'), (1, 'l')):
        A('horn_' + nm, 'head', (s * 3.5, -11, -1), (-1.5, -3, -1.5, 3, 3, 3), gold, rot=(0, 0, s * 0.45), kind='metal')
        A('horn_' + nm + '2', 'horn_' + nm, (s * 1.0, -3, 0), (-1.0, -3, -1.0, 2, 3, 2), gold, rot=(0, 0, s * 0.9), kind='metal')
    # gold ribbon choker + chest bow
    A('choker', 'body', (0, 0, 0), (-2.5, -0.5, -2.5, 5, 1, 5), gold, infl=0.1, kind='metal')
    bow(ch, 'bow', 'body', 0, 2.5, -3.0, gold, C('#C98A22'), w=3, h=3, gap=0.5)
    # skirt (dark) and white shirt hem
    A('skirt', 'body', (0, 9, 0), (-4.5, 0, -2.5, 9, 5, 5), purple, bands=[(0, purple), (0.85, white)])
    A('skirt_back', 'body', (0, 9, 2.5), (-4, 0, 0, 8, 7, 1), dark, rot=(0.15, 0, 0))
    # puffed white sleeves + dark cuffs
    A('sleeve_r', 'right_arm', (0, 0, 0), (-2.5, -2, -2.5, 5, 4, 5), white, infl=0.0)
    A('sleeve_l', 'left_arm', (0, 0, 0), (-2.5, -2, -2.5, 5, 4, 5), white, infl=0.0)
    # gold X patches on thigh-high boots
    A('boot_x_r', 'right_leg', (0, 0, 0), (-1.5, 4.5, -2.3, 3, 3, 1), gold, kind='metal')
    A('boot_x_l', 'left_leg', (0, 0, 0), (-1.5, 4.5, -2.3, 3, 3, 1), gold, kind='metal')
    A('boot_sole_r', 'right_leg', (0, 0, 0), (-2, 12, -3, 4, 2, 5), dark)
    A('boot_sole_l', 'left_leg', (0, 0, 0), (-2, 12, -3, 4, 2, 5), dark)
    # bat-wing cape pieces
    for s, nm in ((-1, 'r'), (1, 'l')):
        A('wing_' + nm, 'body', (s * 3, 2, 2.8), (0 if s > 0 else -11, -2, 0, 11, 8, 1), purple, rot=(0.1, -s * 0.55, s * 0.12))
        A('wing_' + nm + '_bone', 'wing_' + nm, (0, 0, 0), (0 if s > 0 else -11, -3, -0.5, 11, 1, 2), dark)
        A('wing_' + nm + '_low', 'wing_' + nm, (0, 6, 0), (0 if s > 0 else -7, 0, 0, 7, 6, 1), mul(purple, 0.8))
    A('cape', 'body', (0, 0, 2.2), (-4, 0, 0, 8, 13, 1), dark, rot=(0.08, 0, 0))
    return ch


def kiwi():
    ch = Char('kiwi')
    skin = C('#F7D5CB')
    hair, hair_sh = C('#C9CC9A'), C('#A9AD7E')
    green, gdark, red, gold, white, lav = C('#245E2B'), C('#1C4A22'), C('#7A1E30'), C('#E0B84A'), C('#F0EEF2'), C('#BFA6E8')
    humanoid(ch, skin,
             torso=[(0, green)],
             arm=[(0, green), (0.55, red)],
             leg=[(0, skin), (0.38, gdark)])
    ch.face = dict(skin=skin, dark=C('#2B1A2E'), eye=C('#7A3A8A'), blush=C('#F08A98'), mouth=C('#A04858'), lid=True)
    A = ch.add
    hair_shell(ch, hair, back_len=22, side_len=18, back_w=12)
    fringe(ch, hair)
    A('hair_back_lock_r', 'head', (-6, 0, 5), (-3, 0, -1, 4, 14, 3), hair_sh, kind='hair')
    A('hair_back_lock_l', 'head', (6, 0, 5), (-1, 0, -1, 4, 14, 3), hair_sh, kind='hair')
    A('hair_front_lock_r', 'head', (-6.5, -2, -2), (-2, 0, -2, 3, 12, 4), hair, kind='hair')
    A('hair_front_lock_l', 'head', (6.5, -2, -2), (-1, 0, -2, 3, 12, 4), hair, kind='hair')
    A('hair_ribbon_r', 'head', (-7.5, -6, -1), (-1.5, 0, -1.5, 3, 4, 3), lav, kind='cloth')
    A('hair_ribbon_l', 'head', (7.5, -6, -1), (-1.5, 0, -1.5, 3, 4, 3), lav, kind='cloth')
    # beret
    A('beret_band', 'head', (0, 0, 0), (-5.5, -12.0, -5.5, 11, 2, 11), red, kind='cloth', infl=0.1)
    A('beret_trim', 'head', (0, 0, 0), (-5.5, -12.4, -5.6, 11, 1, 1), gold, kind='metal')
    A('beret_top', 'head', (0, -12, 0), (-6, -3, -6, 12, 3, 12), green, rot=(0, 0, 0.12))
    A('beret_cross_v', 'head', (0, -12, 0), (-1, -3.5, -6.4, 2, 4, 1), gold, kind='metal', rot=(0, 0, 0.12))
    A('beret_cross_h', 'head', (0, -12, 0), (-2, -2.5, -6.4, 4, 1, 1), gold, kind='metal', rot=(0, 0, 0.12))
    # high red collar
    A('collar', 'body', (0, 0, 0), (-3.5, -2.0, -2.8, 7, 3, 5), red, infl=0.2)
    A('collar_trim', 'body', (0, 0, 0), (-3.5, 0.8, -2.9, 7, 1, 5), gold, kind='metal', infl=0.2)
    # coat details: gold button strip, medal, tails, frill
    A('coat_buttons', 'body', (0, 0, 0), (1, 1, -2.4, 1, 9, 1), gold, kind='metal')
    A('medal_ribbon', 'body', (0, 0, 0), (-3, 3, -2.4, 2, 3, 1), C('#7FD6C0'))
    A('medal_pin', 'body', (0, 0, 0), (-2.5, 6, -2.5, 1, 1, 1), gold, kind='metal')
    A('coat_skirt', 'body', (0, 9, 0), (-5, 0, -3, 10, 5, 6), green, bands=[(0, green), (0.8, gold)])
    A('coat_frill', 'body', (0, 9, 0), (-4.5, 4.3, -2.6, 9, 2, 5), white, kind='cloth')
    A('coat_tail', 'body', (0, 9, 3), (-4, 0, 0, 8, 10, 1), green, rot=(0.12, 0, 0), bands=[(0, green), (0.85, red)])
    # wide red-gold cuffs
    A('cuff_r', 'right_arm', (0, 0, 0), (-3, 5, -3, 6, 5, 6), red, bands=[(0, red), (0.85, gold)])
    A('cuff_l', 'left_arm', (0, 0, 0), (-3, 5, -3, 6, 5, 6), red, bands=[(0, red), (0.85, gold)])
    # thigh strap + boot cuffs
    A('strap_r', 'right_leg', (0, 0, 0), (-2, 1.5, -2, 4, 1, 4), C('#1C1C1C'), infl=0.3)
    A('strap_l', 'left_leg', (0, 0, 0), (-2, 1.5, -2, 4, 1, 4), C('#1C1C1C'), infl=0.3)
    A('boot_cuff_r', 'right_leg', (0, 0, 0), (-2.5, 4.5, -2.5, 5, 3, 5), red, bands=[(0, red), (0.75, gold)])
    A('boot_cuff_l', 'left_leg', (0, 0, 0), (-2.5, 4.5, -2.5, 5, 3, 5), red, bands=[(0, red), (0.75, gold)])
    A('boot_sole_r', 'right_leg', (0, 0, 0), (-2, 12, -3, 4, 2, 5), C('#14301A'))
    A('boot_sole_l', 'left_leg', (0, 0, 0), (-2, 12, -3, 4, 2, 5), C('#14301A'))
    return ch


def azur():
    ch = Char('azur')
    skin = C('#F8D8D0')
    hair, hair_sh = C('#7ED6B0'), C('#5FBE98')
    blue, lblue, white, shoe, ice = C('#6FA8E0'), C('#9CC8F0'), C('#F2E6F2'), C('#2F6CC0'), C('#CFE9FA')
    humanoid(ch, skin,
             torso=[(0, white), (0.5, blue)],
             arm=[(0, white), (0.28, skin)],
             leg=[(0, skin), (0.88, white)])
    ch.face = dict(skin=skin, dark=C('#2A1A30'), eye=C('#D22A34'), blush=C('#F08A9A'), mouth=C('#B04860'), lid=True)
    A = ch.add
    hair_shell(ch, hair, back_len=20, side_len=14, back_w=12)
    fringe(ch, hair)
    A('hair_back_low', 'head', (0, 9, 5), (-5, 0, 0, 10, 8, 2), hair_sh, kind='hair')
    A('hair_ribbon_a', 'head', (-6.5, -9, -1), (-1.5, 0, -1.5, 3, 4, 3), white)
    A('hair_ribbon_b', 'head', (-6.5, -5, -1), (-1.0, 0, -1.0, 2, 3, 2), lblue)
    A('hair_bow_back_r', 'head', (0, -3, 6.5), (-5, 0, 0, 4, 3, 1), white)
    A('hair_bow_back_l', 'head', (0, -3, 6.5), (1, 0, 0, 4, 3, 1), white)
    bow(ch, 'chestbow', 'body', 0, 2.0, -3.0, lblue, white, w=3, h=3, gap=0.5)
    A('gem', 'body', (0, 0, 0), (-1, 3.0, -3.6, 2, 2, 1), C('#38C8E8'), kind='glow')
    A('skirt', 'body', (0, 9, 0), (-4.5, 0, -2.5, 9, 6, 5), blue, bands=[(0, blue), (0.85, white)])
    A('skirt_frill', 'body', (0, 9, 0), (-5, 5, -3, 10, 2, 6), white)
    A('sleeve_r', 'right_arm', (0, 0, 0), (-2.5, -2, -2.5, 5, 4, 5), white)
    A('sleeve_l', 'left_arm', (0, 0, 0), (-2.5, -2, -2.5, 5, 4, 5), white)
    A('sleeve_stripe_r', 'right_arm', (0, 0, 0), (-2.5, 1.8, -2.5, 5, 1, 5), blue)
    A('sleeve_stripe_l', 'left_arm', (0, 0, 0), (-2.5, 1.8, -2.5, 5, 1, 5), blue)
    for nm in ('r', 'l'):
        A('shoe_' + nm, nm_leg(nm), (0, 0, 0), (-2, 11, -3, 4, 3, 5), shoe)
        A('shoe_strap_' + nm, nm_leg(nm), (0, 0, 0), (-2.5, 10, -2.5, 5, 1, 5), white)
    # ice sword held point-down (right hand)
    A('prop', 'right_arm', (0, 9, -1), (-0.5, -2, -0.5, 1, 3, 1), white, rot=(-0.55, 0, 0))
    A('prop_guard', 'prop', (0, 0, 0), (-3, 0.5, -1, 6, 1, 2), ice, kind='glow')
    A('prop_flake_a', 'prop', (0, 0, 0), (-1, -0.5, -2, 2, 3, 1), ice, kind='glow', rot=(0, 0, 0.5))
    A('prop_flake_b', 'prop', (0, 0, 0), (-1, -0.5, -2, 2, 3, 1), ice, kind='glow', rot=(0, 0, -0.5))
    A('prop_blade', 'prop', (0, 1.5, 0), (-1.5, 0, -0.5, 3, 20, 1), ice, kind='glow')
    A('prop_blade_edge', 'prop', (0, 1.5, 0), (-0.5, 0, -0.9, 1, 20, 1), C('#8FD0F5'), kind='glow')
    A('prop_tip', 'prop', (0, 21.5, 0), (-1, 0, -0.5, 2, 3, 1), ice, kind='glow')
    return ch


def nm_leg(n):
    return 'right_leg' if n == 'r' else 'left_leg'


def magenta():
    ch = Char('magenta')
    skin = C('#F8D7CC')
    hair, hair2 = C('#F277B5'), C('#FA9BCB')
    pink, pink2, white, lpink, black = C('#EB6EA6'), C('#F598C4'), C('#FBF0F6'), C('#F6B6D6'), C('#2A1A28')
    humanoid(ch, skin,
             torso=[(0, white), (0.35, pink)],
             arm=[(0, white), (0.25, pink2)],
             leg=[(0, pink2)])
    ch.face = dict(skin=skin, dark=C('#3A1F30'), eye=C('#28BEAE'), blush=C('#F77FA8'), mouth=C('#C0507A'))
    A = ch.add
    hair_shell(ch, hair, back_len=10, side_len=6, back_w=12)
    fringe(ch, hair)
    A('hair_clip_r', 'head', (-4, -11.5, -1), (-1.5, -2, -1.5, 3, 2, 3), black)
    A('hair_clip_l', 'head', (4, -11.5, -1), (-1.5, -2, -1.5, 3, 2, 3), black)
    for s, nm in ((-1, 'r'), (1, 'l')):
        A('hair_tie_' + nm, 'head', (s * 7.5, -7, 0), (-2, 0, -2, 4, 3, 4), lpink)
        A('hair_tail_' + nm + '1', 'head', (s * 7.5, -4, 0), (-2.5, 0, -2.5, 5, 7, 5), hair, kind='hair')
        A('hair_tail_' + nm + '2', 'hair_tail_' + nm + '1', (0, 7, 0), (-3, 0, -3, 6, 7, 6), hair2, kind='hair')
        A('hair_tail_' + nm + '3', 'hair_tail_' + nm + '2', (0, 7, 0), (-2.5, 0, -2.5, 5, 6, 5), hair, kind='hair')
        A('hair_tail_' + nm + '4', 'hair_tail_' + nm + '3', (0, 6, 0), (-1.5, 0, -1.5, 3, 4, 3), hair2, kind='hair')
    # sailor-like collar bow with heart brooch
    bow(ch, 'bow', 'body', 0, 0.5, -3.0, lpink, pink2, w=3, h=3, gap=0.5)
    A('brooch', 'body', (0, 0, 0), (-1.5, 2.2, -3.4, 3, 3, 1), C('#D8329C'), kind='glow')
    A('chest_frill', 'body', (0, 0, 0), (-3.5, 3.5, -2.5, 7, 3, 1), white)
    A('skirt', 'body', (0, 9, 0), (-4.5, 0, -2.5, 9, 6, 5), pink, bands=[(0, pink), (0.82, white)])
    A('skirt_back_bow_r', 'body', (0, 8, 2.5), (-4, 0, 0, 4, 4, 2), lpink)
    A('skirt_back_bow_l', 'body', (0, 8, 2.5), (0, 0, 0, 4, 4, 2), lpink)
    A('sleeve_r', 'right_arm', (0, 0, 0), (-3, -2, -3, 6, 5, 6), white)
    A('sleeve_l', 'left_arm', (0, 0, 0), (-3, -2, -3, 6, 5, 6), white)
    for nm in ('r', 'l'):
        A('boot_top_' + nm, nm_leg(nm), (0, 0, 0), (-2, 0, -2, 4, 1, 4), white, infl=0.3)
        A('boot_bow_' + nm, nm_leg(nm), (0, 0, 0), (-3, 10, -3.2, 6, 3, 1), white)
        A('boot_heel_' + nm, nm_leg(nm), (0, 0, 0), (-2, 12, -3, 4, 2, 5), C('#E35A98'))
    # heart wand (right hand): short handle + heart head made of cubes
    A('prop', 'right_arm', (0, 9, -1), (-0.5, -3, -0.5, 1, 10, 1), white, rot=(-0.9, 0, 0))
    A('prop_crystal', 'prop', (0, 0, 0), (-1, -6, -1, 2, 3, 2), C('#9ADCF5'), kind='glow')
    A('prop_heart_a', 'prop', (0, 8, 0), (-5, 0, -1, 4, 3, 2), C('#E8309A'), kind='glow')
    A('prop_heart_b', 'prop', (0, 8, 0), (1, 0, -1, 4, 3, 2), C('#E8309A'), kind='glow')
    A('prop_heart_c', 'prop', (0, 8, 0), (-5, 3, -1, 10, 3, 2), C('#E8309A'), kind='glow')
    A('prop_heart_d', 'prop', (0, 8, 0), (-3, 6, -1, 6, 2, 2), C('#E8309A'), kind='glow')
    A('prop_heart_e', 'prop', (0, 8, 0), (-1, 8, -1, 2, 2, 2), C('#E8309A'), kind='glow')
    A('prop_heart_rim', 'prop', (0, 8, 0), (-6, 2.5, -1.5, 12, 1, 1), white)
    return ch


def vika():
    ch = Char('vika')
    skin = C('#F6D6D8')
    hair, hair2 = C('#8E1745'), C('#B8286A')
    mag, black, pink, orange, maroon, gold = C('#A81E5E'), C('#26121F'), C('#E0508E'), C('#F08A30'), C('#6E1428'), C('#E8B85A')
    humanoid(ch, skin,
             torso=[(0, mag), (0.55, black)],
             arm=[(0, pink), (0.3, black), (0.6, skin)],
             leg=[(0, skin), (0.2, black), (0.62, maroon)])
    ch.face = dict(skin=skin, dark=C('#2A1020'), eye=C('#E0283C'), blush=C('#F27FA0'), mouth=C('#A02050'), smirk=True)
    A = ch.add
    hair_shell(ch, hair, back_len=14, side_len=10, back_w=12)
    fringe(ch, hair)
    A('hair_tuft_r', 'head', (-4.5, -11.5, -2), (-1.5, -4, -1.5, 3, 4, 2), hair2, kind='hair', rot=(0, 0, -0.35))
    A('hair_tuft_l', 'head', (4.5, -11.5, -2), (-1.5, -4, -1.5, 3, 4, 2), hair2, kind='hair', rot=(0, 0, 0.35))
    # big curly back hair, three tiers
    A('hair_back_1', 'head', (0, 2, 5.5), (-7, 0, 0, 14, 8, 4), hair2, kind='hair')
    A('hair_back_2', 'hair_back_1', (0, 8, 0), (-8, 0, 0, 16, 8, 4), hair, kind='hair')
    A('hair_back_3', 'hair_back_2', (0, 8, 0), (-7, 0, 0, 14, 7, 4), hair2, kind='hair')
    A('hair_curl_r', 'head', (-7.5, -1, 1), (-2.5, 0, -2.5, 5, 9, 5), hair2, kind='hair')
    A('hair_curl_l', 'head', (7.5, -1, 1), (-2.5, 0, -2.5, 5, 9, 5), hair2, kind='hair')
    A('hair_curl_r2', 'hair_curl_r', (0, 9, 0), (-2, 0, -2, 4, 6, 4), hair, kind='hair')
    A('hair_curl_l2', 'hair_curl_l', (0, 9, 0), (-2, 0, -2, 4, 6, 4), hair, kind='hair')
    A('hair_bow', 'head', (0, -8, 8), (-5, -3, 0, 10, 6, 1), pink)
    A('hair_bow_knot', 'head', (0, -8, 8), (-1.5, -1.5, -0.6, 3, 3, 1), maroon)
    # big curved horns with gold tips
    for s, nm in ((-1, 'r'), (1, 'l')):
        A('horn_' + nm, 'head', (s * 4, -11, -1), (-1.5, -4, -1.5, 3, 4, 3), maroon, rot=(0, 0, s * 0.5), kind='metal')
        A('horn_' + nm + '2', 'horn_' + nm, (s * 1.0, -4, 0), (-1.2, -4, -1.2, 2, 4, 2), maroon, rot=(0, 0, s * 0.8), kind='metal')
        A('horn_' + nm + '3', 'horn_' + nm + '2', (-s * 0.5, -4, 0), (-1, -3, -1, 2, 3, 2), gold, rot=(0, 0, -s * 0.8), kind='metal')
    # frilly dress
    bow(ch, 'bow', 'body', 0, 0.8, -3.0, pink, maroon, w=5, h=5, gap=1.0)
    A('corset', 'body', (0, 0, 0), (-4.2, 6, -2.2, 8, 2, 4), orange, infl=0.15, kind='metal')
    A('skirt', 'body', (0, 9, 0), (-4.5, 0, -2.5, 9, 5, 5), mag, bands=[(0, mag), (0.7, black)])
    A('skirt_frill', 'body', (0, 9, 0), (-5.5, 3.5, -3.5, 11, 3, 7), black, bands=[(0, black), (0.6, pink)])
    A('sleeve_r', 'right_arm', (0, 0, 0), (-2.5, -2, -2.5, 5, 4, 5), pink)
    A('sleeve_l', 'left_arm', (0, 0, 0), (-2.5, -2, -2.5, 5, 4, 5), pink)
    A('glove_r', 'right_arm', (0, 0, 0), (-2, 3, -2, 4, 4, 4), black)
    A('glove_l', 'left_arm', (0, 0, 0), (-2, 3, -2, 4, 4, 4), black)
    for nm in ('r', 'l'):
        A('boot_sole_' + nm, nm_leg(nm), (0, 0, 0), (-2, 12, -3, 4, 2, 5), C('#3A0C18'))
        A('boot_heart_' + nm, nm_leg(nm), (0, 0, 0), (-1, 4, -2.3, 2, 2, 1), pink, kind='glow')
    # demon tail
    A('tail_1', 'body', (0, 9, 2), (-1, -1, 0, 2, 2, 6), black, rot=(0.5, 0, 0))
    A('tail_2', 'tail_1', (0, 0, 6), (-1, -1, 0, 2, 2, 6), maroon, rot=(0.35, 0, 0))
    A('tail_3', 'tail_2', (0, 0, 6), (-1, -1, 0, 2, 2, 5), black, rot=(-0.5, 0, 0))
    A('tail_tip', 'tail_3', (0, 0, 5), (-2, -2, 0, 4, 4, 1), pink, kind='glow')
    # scythe-staff (right hand)
    A('prop', 'right_arm', (0, 9, -0.5), (-0.5, -14, -0.5, 1, 27, 1), maroon, rot=(-0.25, 0, 0))
    A('prop_tip', 'prop', (0, 0, 0), (-1.5, -19, -1.5, 3, 5, 3), C('#FF4FA8'), kind='glow')
    A('prop_blade_1', 'prop', (0, 0, 0), (-1, 10, -5, 2, 2, 6), C('#FF4FA8'), kind='glow')
    A('prop_blade_2', 'prop', (0, 0, 0), (-1, 8, -9, 2, 2, 5), C('#FF6FBA'), kind='glow')
    A('prop_blade_3', 'prop', (0, 0, 0), (-1, 5, -11, 2, 3, 3), C('#FF90CC'), kind='glow')
    A('prop_blade_4', 'prop', (0, 0, 0), (-1, 11, 0, 2, 2, 4), C('#FF4FA8'), kind='glow')
    return ch


def sulfur():
    ch = Char('sulfur')
    skin = C('#F6D6D8')
    hair, hair_shadow = C('#F3C66F'), C('#C99A4B')
    gold, orange, white, dark = C('#E9A52F'), C('#E58A22'), C('#F5EFF0'), C('#80501F')
    humanoid(ch, skin,
             torso=[(0, white), (0.58, gold)],
             arm=[(0, white), (0.55, skin)],
             leg=[(0, skin), (0.18, orange), (0.82, gold)])
    ch.face = dict(skin=skin, dark=C('#34253A'), eye=C('#596CCB'), blush=C('#F28EA1'), mouth=C('#A65D62'), smirk=True)
    A = ch.add
    hair_shell(ch, hair, back_len=15, side_len=12, back_w=13)
    fringe(ch, hair)
    # Long layered rear locks and side locks, matching the reference silhouette.
    A('hair_back_low', 'head', (0, 1, 6), (-6, 0, -1, 12, 13, 3), hair_shadow, kind='hair')
    A('hair_back_low2', 'hair_back_low', (0, 12, 0), (-5, 0, 0, 10, 9, 3), hair, kind='hair')
    for side, nm in ((-1, 'r'), (1, 'l')):
        A('hair_lock_' + nm, 'head', (side * 5.5, -1, 1), (-2, 0, -2, 4, 11, 4), hair_shadow, kind='hair')
        A('hair_lock_' + nm + '2', 'hair_lock_' + nm, (0, 10, 0), (-1.5, 0, -1.5, 3, 9, 3), hair, kind='hair')
        # Cat ears are part of the head silhouette.
        A('cat_ear_' + nm, 'head', (side * 4, -10, 0), (-2, -4, -1, 4, 4, 3), hair, kind='hair')
        A('cat_ear_inner_' + nm, 'cat_ear_' + nm, (0, 0, -0.1), (-1, -2.5, -1.1, 2, 2, 1), C('#E89A9B'))
    # Orange heart-shaped neck bow and golden dress.
    bow(ch, 'neck_bow', 'body', 0, 1.2, -2.8, orange, gold, w=3, h=3, gap=0.5)
    A('dress_skirt', 'body', (0, 9, 0), (-4.5, 0, -2.5, 9, 6, 5), gold, bands=[(0, gold), (0.72, orange)])
    A('dress_hem', 'body', (0, 14, 0), (-5, 0, -3, 10, 2, 6), white)
    A('sleeve_r', 'right_arm', (0, 0, 0), (-2.5, -2, -2.5, 5, 5, 5), white)
    A('sleeve_l', 'left_arm', (0, 0, 0), (-2.5, -2, -2.5, 5, 5, 5), white)
    # Oversized mechanical gauntlets: these are attack gear, not decorative hand jewelry.
    A('fist_r_cuff', 'right_arm', (0, 7, 0), (-2.5, 0, -2.8, 5, 3, 6), dark, kind='metal')
    A('fist_r', 'right_arm', (0, 9, -0.2), (-3.5, 1, -4, 7, 5, 7), orange, kind='metal')
    A('fist_r_plate', 'right_arm', (0, 9, -4.1), (-2.5, 1.5, -0.5, 5, 3, 1), gold, kind='metal')
    A('fist_l_cuff', 'left_arm', (0, 7, 0), (-2.5, 0, -2.8, 5, 3, 6), dark, kind='metal')
    A('fist_l', 'left_arm', (0, 9, -0.2), (-3.5, 1, -4, 7, 5, 7), orange, kind='metal')
    A('fist_l_plate', 'left_arm', (0, 9, -4.1), (-2.5, 1.5, -0.5, 5, 3, 1), gold, kind='metal')
    for nm in ('r', 'l'):
        A('boot_cuff_' + nm, ('right_leg' if nm == 'r' else 'left_leg'), (0, 0, 0), (-2.2, 0, -2.2, 4, 2, 4), white)
    return ch


CHARS = [beze(), kiwi(), azur(), magenta(), vika(), sulfur()]


# ----------------------------------------------------------------------------------------
# Java output
# ----------------------------------------------------------------------------------------
def f(x):
    return repr(float(x)) + 'F'


def rad(d):
    return f(d)  # rotations in this spec are already radians


def java_for(ch):
    lines = []
    names = {}
    fn = ch.id
    lines.append('    private static LayerDefinition %s() {' % fn)
    lines.append('        MeshDefinition mesh = new MeshDefinition();')
    lines.append('        PartDefinition root = mesh.getRoot();')
    for p in ch.parts:
        var = 'p_' + p.name
        names[p.name] = var
        parent = names[p.parent] if p.parent else 'root'
        ox, oy, oz, w, h, d = p.cube
        pose = 'PartPose.offsetAndRotation(%s, %s, %s, %s, %s, %s)' % (
            f(p.piv[0]), f(p.piv[1]), f(p.piv[2]), f(p.rot[0]), f(p.rot[1]), f(p.rot[2]))
        lines.append('        PartDefinition %s = %s.addOrReplaceChild("%s", CubeListBuilder.create().texOffs(%d, %d)'
                     '.addBox(%s, %s, %s, %s, %s, %s, new CubeDeformation(%s)), %s);'
                     % (var, parent, p.name, p.u, p.v, f(ox), f(oy), f(oz), f(w), f(h), f(d), f(p.infl), pose))
    lines.append('        return LayerDefinition.create(mesh, %d, %d);' % (TEXSZ, TEXSZ))
    lines.append('    }')
    return '\n'.join(lines)


def write_java():
    out = ['// GENERATED by tools/gen_assets.py - do not edit by hand.',
           'package com.magicgirls.client.model;', '',
           'import com.magicgirls.entity.GirlType;',
           'import net.minecraft.client.model.geom.PartPose;',
           'import net.minecraft.client.model.geom.builders.CubeDeformation;',
           'import net.minecraft.client.model.geom.builders.CubeListBuilder;',
           'import net.minecraft.client.model.geom.builders.LayerDefinition;',
           'import net.minecraft.client.model.geom.builders.MeshDefinition;',
           'import net.minecraft.client.model.geom.builders.PartDefinition;', '',
           'public final class GirlModels {',
           '    private GirlModels() {}', '',
           '    public static LayerDefinition create(GirlType type) {',
           '        switch (type) {']
    for ch in CHARS:
        out.append('            case %s: return %s();' % (ch.id.upper(), ch.id))
    out += ['            default: throw new IllegalArgumentException(type.name());', '        }', '    }', '']
    out.append('    /** Slash separated paths of every part, indexed by GirlType ordinal. */')
    out.append('    public static final String[][] PATHS = {')
    for ch in CHARS:
        out.append('        {' + ', '.join('"%s"' % ch.path(p) for p in ch.parts) + '},')
    out.append('    };')
    out.append('')
    for ch in CHARS:
        out.append(java_for(ch))
        out.append('')
    out.append('}')
    os.makedirs(os.path.dirname(JAVA), exist_ok=True)
    with open(JAVA, 'w', encoding='utf-8') as fh:
        fh.write('\n'.join(out) + '\n')


def block_texture():
    img = Image.new('RGBA', (16, 16))
    for y in range(16):
        for x in range(16):
            n = hsh(x, y, 99)
            base = mix(C('#3A0B2A'), C('#D8329C'), 0.25 + 0.5 * ((x + y) % 5) / 4.0 * n)
            if (x in (0, 15) or y in (0, 15)):
                base = C('#26121F')
            if 5 <= x <= 10 and 5 <= y <= 10 and abs(x - 7.5) + abs(y - 7.5) < 4:
                base = mix(C('#FF90CC'), C('#FFFFFF'), n * 0.4)
            img.putpixel((x, y), base + (255,))
    os.makedirs(os.path.join(RES, 'textures/block'), exist_ok=True)
    img.save(os.path.join(RES, 'textures/block/vika_portal.png'))


def main():
    os.makedirs(os.path.join(RES, 'textures/entity'), exist_ok=True)
    for ch in CHARS:
        pack(ch)
        used = sum((2 * p.d + 2 * p.w) * (p.d + p.h) for p in ch.parts)
        print('%-8s parts=%3d  texels used=%d/%d' % (ch.id, len(ch.parts), used, TEXSZ * TEXSZ))
        for expr, suffix in (('normal', ''), ('happy', '_happy'), ('sleep', '_sleep')):
            build_texture(ch, expr).save(os.path.join(RES, 'textures/entity/%s%s.png' % (ch.id, suffix)))
    write_java()
    block_texture()
    print('done')


if __name__ == '__main__':
    main()
